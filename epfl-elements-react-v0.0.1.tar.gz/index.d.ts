import * as react_jsx_runtime from 'react/jsx-runtime';
import { ReactNode } from 'react';

type Callback$8 = () => void;
type AlertProps = {
    title: string;
    message: string;
    alertType: string;
    onCloseClick?: Callback$8;
};
declare function Alert({ title, message, alertType, onCloseClick }: AlertProps): react_jsx_runtime.JSX.Element;

type CarouselItemProps = {
    id?: number;
    width?: number;
    height?: number;
    src?: string;
    srcset?: string;
    title?: string;
    link?: string;
    content?: string;
    active?: boolean;
};
type CarouselProps = {
    carouselItems: Array<CarouselItemProps>;
};
declare function Carousel({ carouselItems }: CarouselProps): react_jsx_runtime.JSX.Element;

interface DrawerInnerProps {
    link: string;
    anchor: string;
}
type DrawerProps = {
    contents: DrawerInnerProps;
};
declare function Drawer({ contents }: DrawerProps): react_jsx_runtime.JSX.Element;

type BreadcrumbsItemProps = {
    active?: boolean;
    link?: string;
    anchor?: string;
};
type BreadcrumbsProps = {
    items: Array<BreadcrumbsItemProps>;
};
declare function Breadcrumbs({ items }: BreadcrumbsProps): react_jsx_runtime.JSX.Element;

type CollapseProps = {
    complexHeader?: boolean;
    partialCollapse?: boolean;
    headerTitle?: string;
    headerListValues?: Array<any>;
    idCollapse?: string;
    text?: Array<any>;
    textTitles?: Array<any>;
    label?: string;
};
declare function Collapse({ complexHeader, idCollapse, text, textTitles, label, headerTitle, headerListValues, partialCollapse, }: CollapseProps): react_jsx_runtime.JSX.Element;

type ContentProps = {
    children?: ReactNode;
    mainContainerClass?: string;
};
declare function Content({ children, mainContainerClass }: ContentProps): react_jsx_runtime.JSX.Element;

type ExternalLinkProps = {
    href?: string;
    children?: ReactNode;
};
declare function ExternalLink({ href, children }: ExternalLinkProps): react_jsx_runtime.JSX.Element;

interface ErrorInnerProps {
    status: number;
    message: string;
}
type ErrorProps = {
    error: ErrorInnerProps;
};
declare function Error({ error }: ErrorProps): react_jsx_runtime.JSX.Element;

interface FigureItemProps {
    srcSet: string;
    media: string;
}
type FiguresProps = {
    figCaption?: string;
    src?: string;
    mediaSources?: Array<FigureItemProps>;
    alt?: string;
};
declare function Figures({ figCaption, src, mediaSources, alt }: FiguresProps): react_jsx_runtime.JSX.Element;

type fullTeasterProps = {
    Fullwidthtype?: string;
    titleContent?: string;
    titleMsg?: string;
    btnMsg?: string;
    srcImg?: string;
    footerMsg?: string;
};
declare function Fullwidthteaser({ Fullwidthtype, titleContent, titleMsg, btnMsg, srcImg, footerMsg }: fullTeasterProps): react_jsx_runtime.JSX.Element;

type HeroProps = {
    title?: string;
    content?: string;
    image?: string;
};
declare function Hero({ title, content, image }: HeroProps): react_jsx_runtime.JSX.Element;

type LoaderProps = {
    message?: string;
};
declare function Loader({ message }: LoaderProps): react_jsx_runtime.JSX.Element;

declare function Logo(): react_jsx_runtime.JSX.Element;

type Callback$7 = () => void;
type MetaboxProps = {
    eventTitle?: string;
    metaboxDetails?: Array<any>;
    onClickFn?: Callback$7;
    labelButton?: string;
    organizer?: Array<any>;
};
declare function Metabox({ eventTitle, metaboxDetails, onClickFn, labelButton, organizer, }: MetaboxProps): react_jsx_runtime.JSX.Element;

type CallbackProps = {
    column: string;
    order: string;
    data: Array<any>;
};
type Callback$6 = ({ column, order, data }: CallbackProps) => any;
type TableProps = {
    data?: Array<any>;
    columns?: Array<any>;
    columnsLabels?: Array<any>;
    tagColumns?: any;
    hyperLinks?: Array<any>;
    title?: string;
    showRowTotals?: boolean;
    columnsWithRawHtml?: Array<any>;
    height?: number | string;
    width?: number | string;
    orderCallbackFn?: Callback$6;
};
declare function Table({ data, title, columns, columnsLabels, hyperLinks, tagColumns, showRowTotals, columnsWithRawHtml, width, height, orderCallbackFn }: TableProps): react_jsx_runtime.JSX.Element;

type Callback$5 = (label: string) => void;
type TagProps = {
    id?: number;
    label?: string;
    href?: string;
    className?: string;
    removable?: boolean;
    removeCallback?: Callback$5;
};
declare function Tag({ id, label, href, className, removable, removeCallback }: TagProps): react_jsx_runtime.JSX.Element;

type TagsetProps = {
    tags?: Array<TagProps>;
    callbackFn?: any;
    addLabel?: string;
    className?: string;
    tagSpacing?: string;
    addNewPosition?: string;
    showInColumns?: boolean;
    disableEdit?: boolean;
};
declare function Tagset({ tags, callbackFn, className, addLabel, tagSpacing, addNewPosition, showInColumns, disableEdit }: TagsetProps): react_jsx_runtime.JSX.Element;

type VideoProps = {
    src?: string;
    frameborder?: number;
    allow?: string;
};
declare function Video({ src, frameborder, allow }: VideoProps): react_jsx_runtime.JSX.Element;

type PictureProps = {
    src?: string;
    title?: string;
    alt?: string;
};
type CardProps = {
    picture?: PictureProps;
    children?: ReactNode;
    link?: string;
};
declare function Card({ picture, children, link }: CardProps): react_jsx_runtime.JSX.Element;

type Callback$4 = (e: React.MouseEvent) => void;
type ButtonProps = {
    label?: string;
    onClickFn?: Callback$4;
};
declare function Button({ label, onClickFn }: ButtonProps): react_jsx_runtime.JSX.Element;

type Callback$3 = (e: React.ChangeEvent<HTMLInputElement>) => void;
type CheckboxProps = {
    label?: string;
    onCheckboxChange?: Callback$3;
    isSelected?: boolean;
    checkboxLabelClass?: string;
};
declare function Checkbox({ label, isSelected, checkboxLabelClass, onCheckboxChange }: CheckboxProps): react_jsx_runtime.JSX.Element;

type CheckboxGroupProps = {
    id?: string;
    onChangeFn?: any;
    title?: string;
    options?: Array<string>;
    labels?: Array<string>;
    unchecked?: Array<any>;
    wrapperClass?: string;
    containerClass?: string;
    checkboxLabelClass?: string;
};
declare function CheckboxGroup({ onChangeFn, title, options, labels, unchecked, wrapperClass, containerClass, checkboxLabelClass }: CheckboxGroupProps): react_jsx_runtime.JSX.Element;

declare function CsfrToken({ tokenName, inputName }: {
    tokenName?: string;
    inputName?: string;
}): react_jsx_runtime.JSX.Element;

interface DropdownInnerProps {
    option: string;
    active?: boolean;
}
type DropdownProps = {
    label?: string;
    options?: Array<DropdownInnerProps>;
    onChangeFn?: any;
    placeholder?: string;
};
declare function Dropdown({ label, options, onChangeFn, placeholder }: DropdownProps): react_jsx_runtime.JSX.Element;

type Callback$2 = (e: React.ChangeEvent<HTMLInputElement>) => void;
type InputProps = {
    placeholder?: string;
    onChangeFn?: Callback$2;
    type?: string;
};
declare function Input({ placeholder, onChangeFn, type }: InputProps): react_jsx_runtime.JSX.Element;

type Callback$1 = (data: Array<any>) => any;
type FilterBoxProps = {
    data?: Array<any>;
    updateFn?: Callback$1;
    filterFields?: Array<string>;
    filterLabels?: Array<string>;
    disabledOptions?: object;
    searchbox?: any;
    checkboxLabelClass?: string;
};
declare function FilterBox({ data, filterFields, filterLabels, disabledOptions, searchbox, updateFn, checkboxLabelClass }: FilterBoxProps): react_jsx_runtime.JSX.Element;

type RangeProps = {
    minInput?: number;
    maxInput?: number;
    defaultValue?: number;
    setInput: number;
    label?: string;
    labelValue?: string;
};
declare function Range({ minInput, maxInput, defaultValue, setInput, label, labelValue }: RangeProps): react_jsx_runtime.JSX.Element;

type Callback = (e: React.ChangeEvent<HTMLInputElement>) => void;
type SwitchProps = {
    id?: string;
    label?: string;
    marginLeft?: string;
    onChangeCallback?: Callback;
    isChecked?: boolean;
};
declare function Switch({ id, label, isChecked, marginLeft, onChangeCallback }: SwitchProps): react_jsx_runtime.JSX.Element;

type AsindeMenuSingleItemProps = {
    link?: string;
    anchor?: string;
};
type AsidemenuItemsProps = {
    heading?: string;
    menus?: Array<AsindeMenuSingleItemProps>;
    submenus?: Array<AsidemenuItemsProps>;
};
type AsidemenuProps = {
    isHome?: boolean;
    isLoading?: boolean;
    menuItems?: Array<AsidemenuItemsProps>;
    homeLink?: string;
    homeAnchor?: string;
    feedBackEmail?: string;
    useReactRouterLinks?: boolean;
};
declare function Asidemenu({ isHome, isLoading, menuItems, homeAnchor, homeLink, feedBackEmail, useReactRouterLinks }: AsidemenuProps): react_jsx_runtime.JSX.Element;

type userProps = {
    first_name?: string;
    last_name?: string;
    sciper?: string;
    photo_url?: string;
};
type AvatarProps = {
    user?: userProps;
    logOutUrl?: string;
    logoUrl?: string;
    logoAltText?: string;
};
declare function Avatar({ user, logOutUrl, logoUrl, logoAltText }: AvatarProps): react_jsx_runtime.JSX.Element;

type LanguageProps = {
    active?: string;
    enLink?: string;
    frLink?: string;
};
declare function Language({ active, enLink, frLink }: LanguageProps): react_jsx_runtime.JSX.Element;

type MenuItemProps = {
    heading: string;
    link: string;
    currentItem?: boolean;
    menus?: Array<MenuItemProps>;
};
type MainMenuProps = {
    mainMenuStructure?: Array<MenuItemProps>;
    useReactRouterLinks?: boolean;
};
declare function MainMenu({ mainMenuStructure, useReactRouterLinks }: MainMenuProps): react_jsx_runtime.JSX.Element;

interface TopmenuInnerProps {
    active?: boolean;
    link?: string;
    anchor?: string;
}
type TopmenuProps = {
    menuItems?: Array<TopmenuInnerProps>;
};
declare function Topmenu({ menuItems }: TopmenuProps): react_jsx_runtime.JSX.Element;

declare function Footer({ sitemap, schools }: {
    sitemap?: {
        heading_fr: string;
        heading_en: string;
        heading_de: string;
        items: ({
            name_fr: string;
            url_fr: string;
            name_en: string;
            url_en: string;
            name_de: string;
            url_de: string;
            target_blank_fr?: undefined;
            rel_noopener_fr?: undefined;
            target_blank_en?: undefined;
            rel_noopener_en?: undefined;
            target_blank_de?: undefined;
            rel_noopener_de?: undefined;
        } | {
            name_fr: string;
            url_fr: string;
            target_blank_fr: boolean;
            rel_noopener_fr: boolean;
            name_en: string;
            url_en: string;
            target_blank_en: boolean;
            rel_noopener_en: boolean;
            name_de: string;
            url_de: string;
            target_blank_de: boolean;
            rel_noopener_de: boolean;
        })[];
    }[];
    schools?: ({
        name_fr: string;
        name_en: string;
        name_de: string;
        acronym: string;
        url_fr: string;
        url_en: string;
        url_de: string;
        target_blank_fr?: undefined;
        rel_noopener_fr?: undefined;
        target_blank_en?: undefined;
        rel_noopener_en?: undefined;
        target_blank_de?: undefined;
        rel_noopener_de?: undefined;
    } | {
        name_fr: string;
        name_en: string;
        name_de: string;
        acronym: string;
        url_fr: string;
        target_blank_fr: boolean;
        rel_noopener_fr: boolean;
        url_en: string;
        target_blank_en: boolean;
        rel_noopener_en: boolean;
        url_de: string;
        target_blank_de: boolean;
        rel_noopener_de: boolean;
    })[];
}): react_jsx_runtime.JSX.Element;

declare function FooterLight(): react_jsx_runtime.JSX.Element;

type HeaderProps = {
    topMenuItems?: Array<any>;
    drawerContents?: DrawerInnerProps;
    user?: object;
    logOutUrl?: string;
    avatarLogoUrl?: string;
    avatarLogoAltText?: string;
};
declare function Header({ topMenuItems, drawerContents, user, logOutUrl, avatarLogoUrl, avatarLogoAltText }: HeaderProps): react_jsx_runtime.JSX.Element;

type TabsetProps = {
    tabs: any;
};

declare function Tabset({ tabs }: TabsetProps): react_jsx_runtime.JSX.Element;

type updateContensSingleProps = {
    tab: any;
    tabContents?: any;
    setTabFn?: any;
};
declare function tabUpdateContents({ tab, tabContents, setTabFn }: updateContensSingleProps): void;

type BaseProps = {
    feedBackEmail?: string;
    homeAnchor?: string;
    homeLink?: string;
    isHome?: boolean;
    isBeta?: boolean;
    isLoading?: boolean;
    children?: JSX.Element;
    user?: object;
    breadcrumbItems?: Array<BreadcrumbsItemProps>;
    topMenuItems?: Array<TopmenuInnerProps>;
    showFooter?: boolean;
    useLightFooter?: boolean;
    drawerContents?: DrawerInnerProps;
    avatarLogoAltText?: string;
    avatarLogoUrl?: string;
    mainContainerClass?: string;
    title?: string;
    baseTitle?: string;
    asideMenuItems?: Array<AsidemenuItemsProps>;
    useReactRouterLinks?: boolean;
};
declare function Base({ children, user, feedBackEmail, homeAnchor, homeLink, isHome, isLoading, isBeta, asideMenuItems, topMenuItems, breadcrumbItems, drawerContents, showFooter, useLightFooter, mainContainerClass, baseTitle, title, avatarLogoUrl, avatarLogoAltText, useReactRouterLinks }: BaseProps): react_jsx_runtime.JSX.Element;

export { Alert, Asidemenu, Avatar, Base, Breadcrumbs, Button, Card, Carousel, Checkbox, CheckboxGroup, Collapse, Content, CsfrToken, Drawer, Dropdown, Error, ExternalLink, Figures, FilterBox, Footer, FooterLight, Fullwidthteaser, Header, Hero, Input, Language, Loader, Logo, MainMenu, Metabox, Range, Switch, Table, Tabset, Tag, Tagset, Topmenu, Video, tabUpdateContents };
