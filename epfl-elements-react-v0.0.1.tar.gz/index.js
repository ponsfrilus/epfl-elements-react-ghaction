"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/index.ts
var src_exports = {};
__export(src_exports, {
  Alert: () => Alert,
  Asidemenu: () => Asidemenu,
  Avatar: () => Avatar,
  Base: () => Base,
  Breadcrumbs: () => Breadcrumbs,
  Button: () => Button,
  Card: () => Card,
  Carousel: () => Carousel,
  Checkbox: () => Checkbox,
  CheckboxGroup: () => CheckboxGroup,
  Collapse: () => Collapse,
  Content: () => Content,
  CsfrToken: () => CsfrToken,
  Drawer: () => Drawer,
  Dropdown: () => Dropdown,
  Error: () => Error2,
  ExternalLink: () => ExternalLink,
  Figures: () => Figures,
  FilterBox: () => FilterBox,
  Footer: () => Footer,
  FooterLight: () => FooterLight,
  Fullwidthteaser: () => Fullwidthteaser,
  Header: () => Header,
  Hero: () => Hero,
  Input: () => Input,
  Language: () => Language,
  Loader: () => Loader,
  Logo: () => Logo,
  MainMenu: () => MainMenu,
  Metabox: () => Metabox,
  Range: () => Range,
  Switch: () => Switch,
  Table: () => Table,
  Tabset: () => Tabset,
  Tag: () => Tag,
  Tagset: () => Tagset,
  Topmenu: () => Topmenu,
  Video: () => Video,
  tabUpdateContents: () => tabUpdateContents
});
module.exports = __toCommonJS(src_exports);
var import_elements_min19 = require("epfl-elements/dist/css/elements.min.css");
var import_reader_min = require("epfl-elements/dist/css/reader.min.css");
var import_vendors_min = require("epfl-elements/dist/css/vendors.min.css");

// src/components/Alert/index.tsx
var import_react = require("react");
var import_elements_min = require("epfl-elements/dist/css/elements.min.css");
var import_jsx_runtime = require("react/jsx-runtime");
function Alert({ title = "", message = "", alertType = "info", onCloseClick }) {
  const [showAlert, setShowalert] = (0, import_react.useState)(true);
  const getClassName = () => `alert alert-${alertType} alert-dismissible fade show`;
  const onClickLocal = () => {
    setShowalert(false);
    if (onCloseClick) {
      onCloseClick();
      return;
    }
  };
  return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children: showAlert && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: getClassName(), role: "alert", children: [
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: title }),
    " ",
    message,
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", { type: "button", className: "close", "data-dismiss": "alert", "aria-label": "Close", onClick: onClickLocal, children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { "aria-hidden": "true", children: "\xD7" }) })
  ] }) });
}

// src/components/Carousel/index.tsx
var import_react2 = require("react");
var import_elements_min2 = require("epfl-elements/dist/css/elements.min.css");

// #style-inject:#style-inject
function styleInject(css, { insertAt } = {}) {
  if (!css || typeof document === "undefined")
    return;
  const head = document.head || document.getElementsByTagName("head")[0];
  const style = document.createElement("style");
  style.type = "text/css";
  if (insertAt === "top") {
    if (head.firstChild) {
      head.insertBefore(style, head.firstChild);
    } else {
      head.appendChild(style);
    }
  } else {
    head.appendChild(style);
  }
  if (style.styleSheet) {
    style.styleSheet.cssText = css;
  } else {
    style.appendChild(document.createTextNode(css));
  }
}

// src/components/Carousel/index.css
styleInject(`.carousel {
  position: relative;
}
.carousel.pointer-event {
  -ms-touch-action: pan-y;
  touch-action: pan-y;
}
.carousel-inner {
  position: relative;
  width: 100%;
  overflow: hidden;
}
.carousel-inner::after {
  display: block;
  clear: both;
  content: "";
}
.carousel-item {
  position: relative;
  display: none;
  float: left;
  width: 100%;
  margin-right: -100%;
  -webkit-backface-visibility: hidden;
  backface-visibility: hidden;
  -webkit-transition: -webkit-transform 0.6s ease;
  transition: -webkit-transform 0.6s ease;
  transition: transform 0.6s ease;
  transition: transform 0.6s ease, -webkit-transform 0.6s ease;
}
@media (prefers-reduced-motion: reduce) {
  .carousel-item {
    -webkit-transition: none;
    transition: none;
  }
}
.carousel-item.active,
.carousel-item-next,
.carousel-item-prev {
  display: block;
}
.carousel-item-next:not(.carousel-item-left),
.active.carousel-item-right {
  -webkit-transform: translateX(100%);
  transform: translateX(100%);
}
.carousel-item-prev:not(.carousel-item-right),
.active.carousel-item-left {
  -webkit-transform: translateX(-100%);
  transform: translateX(-100%);
}
.carousel-fade .carousel-item {
  opacity: 0;
  -webkit-transition-property: opacity;
  transition-property: opacity;
  -webkit-transform: none;
  transform: none;
}
.carousel-fade .carousel-item.active,
.carousel-fade .carousel-item-next.carousel-item-left,
.carousel-fade .carousel-item-prev.carousel-item-right {
  z-index: 1;
  opacity: 1;
}
.carousel-fade .active.carousel-item-left,
.carousel-fade .active.carousel-item-right {
  z-index: 0;
  opacity: 0;
  -webkit-transition: opacity 0s 0.6s;
  transition: opacity 0s 0.6s;
}
@media (prefers-reduced-motion: reduce) {
  .carousel-fade .active.carousel-item-left,
  .carousel-fade .active.carousel-item-right {
    -webkit-transition: none;
    transition: none;
  }
}
.carousel-control-prev,
.carousel-control-next {
  position: absolute;
  top: 0;
  bottom: 0;
  z-index: 1;
  display: -webkit-box;
  display: -ms-flexbox;
  display: flex;
  -webkit-box-align: center;
  -ms-flex-align: center;
  align-items: center;
  -webkit-box-pack: center;
  -ms-flex-pack: center;
  justify-content: center;
  width: 15%;
  color: #fff;
  text-align: center;
  opacity: 0.5;
  -webkit-transition: opacity 0.15s ease;
  transition: opacity 0.15s ease;
}
@media (prefers-reduced-motion: reduce) {
  .carousel-control-prev,
  .carousel-control-next {
    -webkit-transition: none;
    transition: none;
  }
}
.carousel-control-prev:hover,
.carousel-control-prev:focus,
.carousel-control-next:hover,
.carousel-control-next:focus {
  color: #fff;
  text-decoration: none;
  outline: 0;
  opacity: 0.9;
}
.carousel-control-prev {
  left: 0;
}
.carousel-control-next {
  right: 0;
}
.carousel-control-prev-icon,
.carousel-control-next-icon {
  display: inline-block;
  width: 20px;
  height: 20px;
  background: 50% / 100% 100% no-repeat;
}
.carousel-control-prev-icon {
  background-image: url("data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='%23fff' viewBox='0 0 8 8'%3E%3Cpath d='M5.25 0l-4 4 4 4 1.5-1.5-2.5-2.5 2.5-2.5-1.5-1.5z'/%3E%3C/svg%3E");
}
.carousel-control-next-icon {
  background-image: url("data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='%23fff' viewBox='0 0 8 8'%3E%3Cpath d='M2.75 0l-1.5 1.5 2.5 2.5-2.5 2.5 1.5 1.5 4-4-4-4z'/%3E%3C/svg%3E");
}
.carousel-indicators {
  position: absolute;
  right: 0;
  bottom: 0;
  left: 0;
  z-index: 15;
  display: -webkit-box;
  display: -ms-flexbox;
  display: flex;
  -webkit-box-pack: center;
  -ms-flex-pack: center;
  justify-content: center;
  padding-left: 0;
  margin-right: 15%;
  margin-left: 15%;
  list-style: none;
}
.carousel-indicators li {
  -webkit-box-sizing: content-box;
  box-sizing: content-box;
  -webkit-box-flex: 0;
  -ms-flex: 0 1 auto;
  flex: 0 1 auto;
  width: 30px;
  height: 3px;
  margin-right: 3px;
  margin-left: 3px;
  text-indent: -999px;
  cursor: pointer;
  background-color: #fff;
  background-clip: padding-box;
  border-top: 10px solid transparent;
  border-bottom: 10px solid transparent;
  opacity: .5;
  -webkit-transition: opacity 0.6s ease;
  transition: opacity 0.6s ease;
}
@media (prefers-reduced-motion: reduce) {
  .carousel-indicators li {
    -webkit-transition: none;
    transition: none;
  }
}
.carousel-indicators .active {
  opacity: 1;
}
.carousel-caption {
  position: absolute;
  right: 15%;
  bottom: 20px;
  left: 15%;
  z-index: 10;
  padding-top: 20px;
  padding-bottom: 20px;
  color: #fff;
  text-align: center;
}
.carousel {
  overflow: hidden;
}
.carousel-control {
  padding: 0 2rem;
  background: transparent;
  border: 0;
  cursor: pointer;
  font-size: 2rem;
  -webkit-transition: all .3s ease-in-out;
  transition: all .3s ease-in-out;
}
.carousel-control .icon {
  width: 1.5em;
  height: 1.5em;
  padding: 0.5rem;
  background: rgba(255, 255, 255, 0.6);
  border-radius: 50%;
  color: #000;
  -webkit-transition: all .2s;
  transition: all .2s;
}
.carousel-control:hover {
  opacity: 1;
  padding-left: 1rem;
  padding-right: 1rem;
}
.carousel-control:hover .icon {
  background: rgba(255, 255, 255, 0.8);
}
.carousel-control-prev {
  -webkit-box-pack: start;
  -ms-flex-pack: start;
  justify-content: flex-start;
}
.carousel-control-prev .icon {
  padding-right: 0.625rem;
  padding-left: 0.375rem;
}
.carousel-control-next {
  -webkit-box-pack: end;
  -ms-flex-pack: end;
  justify-content: flex-end;
}
.carousel-control-next .icon {
  padding-right: 0.375rem;
  padding-left: 0.625rem;
}
.carousel-indicators {
  bottom: 0;
  margin: 0;
  padding: 0 15% 1rem;
}
.carousel-indicators:before {
  content: "";
  position: absolute;
  top: auto;
  right: 0;
  bottom: 0;
  left: 0;
  height: 6rem;
  opacity: .3;
  background: -webkit-gradient(linear, left top, left bottom, from(rgba(0, 0, 0, 0)), to(black));
  background: linear-gradient(to bottom, rgba(0, 0, 0, 0) 0%, black 100%);
}
.carousel-indicators li {
  border-top: inherit;
  border-bottom: inherit;
  border-radius: 50%;
  cursor: pointer;
  width: 12px;
  height: 12px;
  margin: 0 5px;
  padding: 0;
}
.carousel-indicators li:before {
  content: none;
}
@media (max-width: 1199.98px) {
  .carousel-control {
    display: none;
  }
  .carousel-indicators {
    position: static;
    padding: 1.5rem 15% 0;
  }
  .carousel-indicators:before {
    display: none;
  }
  .carousel-indicators li {
    width: 14px;
    height: 14px;
    background: #d5d5d5;
  }
  .carousel-indicators li.active {
    background: #ff0000;
  }
  .carousel-highlighted-news .carousel-indicators {
    padding-top: .5rem;
  }
}
`);

// src/components/Carousel/index.tsx
var import_jsx_runtime2 = require("react/jsx-runtime");
function Carousel({ carouselItems }) {
  const [activeId, setActiveId] = (0, import_react2.useState)(carouselItems.filter((item) => item.active)[0].id);
  const positionIds = carouselItems.reduce((obj, item, i) => {
    obj[item.id] = i;
    return obj;
  }, {});
  function switchNextItem() {
    const currentPosition = positionIds[activeId];
    const nextPosition = currentPosition + 1;
    const nextId = (carouselItems[nextPosition] || carouselItems[0]).id;
    setActiveId(nextId);
  }
  function switchPreviousItem() {
    const currentPosition = positionIds[activeId];
    const previousPosition = currentPosition - 1;
    const previousId = (carouselItems[previousPosition] || carouselItems[carouselItems.length - 1]).id;
    setActiveId(previousId);
  }
  const getSingleCarouselItem = (item) => /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("div", { className: item.id === activeId ? "carousel-item active" : "carousel-item", children: /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("div", { className: "fullwidth-teaser fullwidth-teaser-horizontal", children: [
    /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("picture", { children: /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("img", { width: item.width, height: item.height, src: item.src, className: "attachment-thumbnail_16_9_large_80p size-thumbnail_16_9_large_80p", alt: "", loading: "lazy", title: "", srcSet: item.srcset, sizes: `(max-width: ${item.width}) 100vw, ${item.width}px` }) }),
    /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("div", { className: "fullwidth-teaser-text", children: [
      /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("div", { className: "fullwidth-teaser-header", children: [
        /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("div", { className: "fullwidth-teaser-title", children: /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("h3", { children: item.title }) }),
        /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("a", { href: item.link, target: "_blank", "aria-label": "Link to read more of that page", className: "btn btn-primary triangle-outer-top-right d-none d-xl-block", children: [
          "Read more ",
          /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("svg", { className: "icon", "aria-hidden": "true", children: /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("use", { xlinkHref: "#icon-chevron-right" }) })
        ] })
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("div", { className: "fullwidth-teaser-content", children: /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("p", { children: item.content }) }),
      /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("div", { className: "fullwidth-teaser-footer", children: /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("a", { href: item.link, "aria-label": "Link to read more of that page", className: "btn btn-primary btn-block d-xl-none", children: "Read more" }) })
    ] })
  ] }) });
  const getChevronIcons = () => /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("div", { style: { display: "none" }, children: /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("svg", { xmlns: "http://www.w3.org/2000/svg", children: [
    /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("symbol", { id: "icon-chevron-left", viewBox: "0 0 24 24", children: /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("path", { fill: "currentColor", d: "m16.9 6.1-1.9-2L7.1 12l7.9 7.9 1.9-2L11 12z" }) }),
    /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("symbol", { id: "icon-chevron-right", viewBox: "0 0 24 24", children: /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("path", { fill: "currentColor", d: "m7.1 17.9 1.9 2 7.9-7.9L9 4.1l-1.9 2L13 12z" }) })
  ] }) });
  const getCarouselIndicators = () => /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("ol", { className: "carousel-indicators", children: carouselItems && carouselItems.map(
    (item, i) => /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(
      "li",
      {
        "data-target": "#carouselNews",
        "data-slide-to": i,
        onClick: () => setActiveId(item.id),
        className: item.id === activeId ? "active" : ""
      },
      `carInd${i}`
    )
  ) });
  const getNextPreviousButtons = () => /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)(import_jsx_runtime2.Fragment, { children: [
    /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)(
      "button",
      {
        className: "carousel-control carousel-control-prev",
        type: "button",
        "data-slide": "prev",
        "data-target": "#carouselNews",
        onClick: () => switchPreviousItem(),
        children: [
          /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("svg", { className: "icon", "aria-hidden": "true", children: /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("use", { xlinkHref: "#icon-chevron-left" }) }),
          /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("span", { className: "sr-only", children: "Previous" })
        ]
      }
    ),
    /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)(
      "button",
      {
        className: "carousel-control carousel-control-next",
        type: "button",
        "data-slide": "next",
        "data-target": "#carouselNews",
        onClick: () => switchNextItem(),
        children: [
          /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("svg", { className: "icon", "aria-hidden": "true", children: /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("use", { xlinkHref: "#icon-chevron-right" }) }),
          /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("span", { className: "sr-only", children: "Next" })
        ]
      }
    )
  ] });
  function renderCarousel() {
    return /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)(import_jsx_runtime2.Fragment, { children: [
      getChevronIcons(),
      /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("div", { className: "container-full", children: /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("div", { id: "carouselNews", className: "carousel slide carousel-highlighted-news", "data-ride": "carousel", "data-interval": "6000", children: [
        /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("div", { className: "carousel-inner", children: carouselItems && carouselItems.map((item) => getSingleCarouselItem(item)) }),
        getCarouselIndicators(),
        getNextPreviousButtons()
      ] }) })
    ] });
  }
  return /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(import_jsx_runtime2.Fragment, { children: carouselItems && activeId && renderCarousel() });
}

// src/components/Drawer/index.tsx
var import_react3 = require("react");
var import_elements_min3 = require("epfl-elements/dist/css/elements.min.css");
var import_jsx_runtime3 = require("react/jsx-runtime");
function Drawer({ contents }) {
  const [drawerOpen, setDrawerOpen] = (0, import_react3.useState)(false);
  const toogleDrawer = () => setDrawerOpen(!drawerOpen);
  const getDrawerClassName = () => drawerOpen ? "drawer mr-3 mr-xl-0 open" : "drawer mr-3 mr-xl-0";
  const getDrawerStyle = () => drawerOpen ? { width: "182.031px" } : void 0;
  const getDrawerSvg = () => /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("svg", { className: "icon", "aria-hidden": "true", children: /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("use", { xlinkHref: "#icon-chevron-right", children: /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("svg", { id: "icon-chevron-right", viewBox: "0 0 24 24", children: /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("path", { fill: "currentColor", d: "M7.1 17.9l1.9 2 7.9-7.9L9 4.1l-1.9 2L13 12z" }) }) }) });
  return /* @__PURE__ */ (0, import_jsx_runtime3.jsxs)("div", { className: getDrawerClassName(), style: getDrawerStyle(), children: [
    /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("button", { className: "drawer-toggle", onClick: toogleDrawer, children: getDrawerSvg() }),
    /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(
      "a",
      {
        href: contents.link,
        className: "drawer-link",
        style: getDrawerStyle(),
        target: "_blank",
        rel: "noopener noreferrer",
        children: /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("span", { className: "text", children: contents.anchor })
      }
    )
  ] });
}

// src/components/Breadcrumbs/index.tsx
var import_elements_min4 = require("epfl-elements/dist/css/elements.min.css");
var import_jsx_runtime4 = require("react/jsx-runtime");
var getBreadCrumbItem = (item, i) => /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(
  "li",
  {
    style: { marginRight: "0.4em" },
    className: item.active ? "breadcrumb-item active" : "breadcrumb-item",
    children: item.active ? item.anchor : /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("a", { href: item.link, target: "_blank", rel: "noopener noreferrer", children: item.anchor }, `a-${i}`)
  },
  `li-${i}`
);
function Breadcrumbs({ items }) {
  return /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("div", { className: "breadcrumb-container", children: /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("nav", { "aria-label": "breadcrumb", className: "breadcrumb-wrapper", children: /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)("ol", { className: "breadcrumb", children: [
    /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("li", { className: "breadcrumb-item", style: { marginRight: "0.4em" }, children: /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("a", { href: "https://www.epfl.ch", target: "_blank", rel: "noopener noreferrer", children: /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("svg", { className: "icon", "aria-hidden": "true", children: /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("use", { xlinkHref: "#icon-home", children: /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("svg", { id: "icon-home", viewBox: "0 0 11 12", children: /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("path", { d: "M0 5l5.25-5 5.25 5v7H0z", fillRule: "evenodd" }) }) }) }) }) }),
    items && items.map((item, x) => getBreadCrumbItem(item, x))
  ] }) }) });
}

// src/components/Collapse/index.tsx
var import_react4 = require("react");
var import_jsx_runtime5 = require("react/jsx-runtime");
function Collapse({
  complexHeader,
  idCollapse,
  text,
  textTitles,
  label,
  headerTitle,
  headerListValues,
  partialCollapse
}) {
  const [stateCollapseText, setStateCollapseText] = (0, import_react4.useState)(false);
  const onClickFn = () => {
    if (stateCollapseText) {
      setStateCollapseText(false);
    } else {
      setStateCollapseText(true);
    }
  };
  const classNameFn = partialCollapse ? "collapsed btn btn-light btn-block btn-sm mt-3" : "collapse-title collapse-title-desktop collapsed";
  const classDivNameFn = partialCollapse ? "collapse collapse-partial" : "collapse collapse-item collapse-item-desktop collapsed";
  const getText = () => /* @__PURE__ */ (0, import_jsx_runtime5.jsx)("div", { className: stateCollapseText ? `${classDivNameFn} show` : classDivNameFn, id: idCollapse, children: (text || []).map((item, i) => {
    if (textTitles) {
      return /* @__PURE__ */ (0, import_jsx_runtime5.jsxs)(import_jsx_runtime5.Fragment, { children: [
        /* @__PURE__ */ (0, import_jsx_runtime5.jsx)("h3", { children: textTitles[i] }),
        /* @__PURE__ */ (0, import_jsx_runtime5.jsx)("p", { children: item }, i)
      ] });
    } else {
      return /* @__PURE__ */ (0, import_jsx_runtime5.jsx)(import_jsx_runtime5.Fragment, { children: /* @__PURE__ */ (0, import_jsx_runtime5.jsx)("p", { children: item }, i) });
    }
  }) });
  const buttonParameters = () => /* @__PURE__ */ (0, import_jsx_runtime5.jsx)(import_jsx_runtime5.Fragment, { children: /* @__PURE__ */ (0, import_jsx_runtime5.jsx)(
    "button",
    {
      className: classNameFn,
      "data-label": label,
      "data-target": `#${idCollapse}`,
      "data-toogle": "collapse",
      "aria-controls": idCollapse,
      "aria-expanded": stateCollapseText,
      onClick: () => onClickFn(),
      children: label
    }
  ) });
  const collapseButtonAndText = () => {
    if (partialCollapse) {
      return /* @__PURE__ */ (0, import_jsx_runtime5.jsxs)(import_jsx_runtime5.Fragment, { children: [
        getText(),
        buttonParameters()
      ] });
    } else {
      return /* @__PURE__ */ (0, import_jsx_runtime5.jsxs)(import_jsx_runtime5.Fragment, { children: [
        buttonParameters(),
        getText()
      ] });
    }
  };
  const headerParametersAndText = () => /* @__PURE__ */ (0, import_jsx_runtime5.jsxs)(import_jsx_runtime5.Fragment, { children: [
    /* @__PURE__ */ (0, import_jsx_runtime5.jsxs)(
      "header",
      {
        className: classNameFn,
        "data-target": `#${idCollapse}`,
        "data-toogle": "collapse",
        "aria-controls": idCollapse,
        "aria-expanded": stateCollapseText,
        onClick: () => onClickFn(),
        children: [
          /* @__PURE__ */ (0, import_jsx_runtime5.jsx)(
            "p",
            {
              className: "title",
              children: headerTitle
            }
          ),
          /* @__PURE__ */ (0, import_jsx_runtime5.jsx)(
            "ul",
            {
              className: "list-inline has-sep small text-muted",
              children: (headerListValues || []).map(
                (item, i) => /* @__PURE__ */ (0, import_jsx_runtime5.jsx)("li", { children: item }, i)
              )
            }
          )
        ]
      }
    ),
    getText()
  ] });
  return /* @__PURE__ */ (0, import_jsx_runtime5.jsxs)(import_jsx_runtime5.Fragment, { children: [
    !complexHeader && collapseButtonAndText(),
    complexHeader && headerParametersAndText()
  ] });
}

// src/components/Content/index.tsx
var import_jsx_runtime6 = require("react/jsx-runtime");
function Content({ children, mainContainerClass }) {
  const mainContainerClassName = mainContainerClass ? mainContainerClass : "content container-grid";
  return /* @__PURE__ */ (0, import_jsx_runtime6.jsx)("div", { className: "w-100 pb-5", children: /* @__PURE__ */ (0, import_jsx_runtime6.jsx)("main", { id: "main", role: "main", className: mainContainerClassName, children }) });
}

// src/components/Links/index.tsx
var import_elements_min5 = require("epfl-elements/dist/css/elements.min.css");
var import_jsx_runtime7 = require("react/jsx-runtime");
function ExternalLink({ href, children }) {
  const getLink = () => /* @__PURE__ */ (0, import_jsx_runtime7.jsx)("a", { target: "_blank", rel: "noopener noreferrer", href, children });
  return /* @__PURE__ */ (0, import_jsx_runtime7.jsx)(import_jsx_runtime7.Fragment, { children: href && children && getLink() });
}

// src/components/Error/index.css
styleInject(".error-title {\n  color: red !important;\n  font-size: 12vw !important;\n  margin-bottom: .75rem !important;\n  text-align: center !important;\n}\n");

// src/components/Error/index.tsx
var import_jsx_runtime8 = require("react/jsx-runtime");
function Error2({ error }) {
  return /* @__PURE__ */ (0, import_jsx_runtime8.jsx)("div", { id: "primary", className: "content-area", children: /* @__PURE__ */ (0, import_jsx_runtime8.jsx)("main", { id: "main", className: "site-main", children: /* @__PURE__ */ (0, import_jsx_runtime8.jsx)("section", { className: "error-404 not-found", children: /* @__PURE__ */ (0, import_jsx_runtime8.jsxs)("div", { className: "page-content container", children: [
    error.status && /* @__PURE__ */ (0, import_jsx_runtime8.jsx)("p", { className: "h1 mt-4 error-title", children: error.status }),
    error.message && /* @__PURE__ */ (0, import_jsx_runtime8.jsx)("h1", { className: "h3 text-center", children: error.message }),
    !error.message && /* @__PURE__ */ (0, import_jsx_runtime8.jsx)("h1", { className: "h3 text-center", children: "Server error please try again" })
  ] }) }) }) });
}

// src/components/Figures/index.tsx
var import_jsx_runtime9 = require("react/jsx-runtime");
function Figures({ figCaption, src, mediaSources, alt }) {
  return /* @__PURE__ */ (0, import_jsx_runtime9.jsx)("div", { children: /* @__PURE__ */ (0, import_jsx_runtime9.jsxs)("figure", { children: [
    /* @__PURE__ */ (0, import_jsx_runtime9.jsxs)("picture", { children: [
      mediaSources && mediaSources.map(
        ({ srcSet, media }, i) => srcSet && media && /* @__PURE__ */ (0, import_jsx_runtime9.jsx)("source", { media, srcSet }, i)
      ),
      /* @__PURE__ */ (0, import_jsx_runtime9.jsx)("img", { src, className: "img-fluid", alt })
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime9.jsx)("figcaption", { children: figCaption })
  ] }) });
}

// src/components/Fullwidthteaser/index.tsx
var import_jsx_runtime10 = require("react/jsx-runtime");
function Fullwidthteaser({ Fullwidthtype, titleContent, titleMsg, btnMsg, srcImg, footerMsg }) {
  return /* @__PURE__ */ (0, import_jsx_runtime10.jsxs)("div", { className: Fullwidthtype, children: [
    /* @__PURE__ */ (0, import_jsx_runtime10.jsx)("picture", { children: /* @__PURE__ */ (0, import_jsx_runtime10.jsx)("img", { src: srcImg, "aria-labelledby": "background-label", alt: "An image description" }) }),
    /* @__PURE__ */ (0, import_jsx_runtime10.jsxs)("div", { className: "fullwidth-teaser-text", children: [
      /* @__PURE__ */ (0, import_jsx_runtime10.jsxs)("div", { className: "fullwidth-teaser-header", children: [
        /* @__PURE__ */ (0, import_jsx_runtime10.jsx)("div", { className: "fullwidth-teaser-title", children: /* @__PURE__ */ (0, import_jsx_runtime10.jsx)("h3", { children: titleMsg }) }),
        /* @__PURE__ */ (0, import_jsx_runtime10.jsxs)("a", { href: "#", "aria-label": "En savoir plus sur Tech Transfer", className: "btn btn-primary triangle-outer-bottom-right d-none d-xl-block", children: [
          btnMsg,
          /* @__PURE__ */ (0, import_jsx_runtime10.jsx)("svg", { className: "icon", "aria-hidden": "true", children: /* @__PURE__ */ (0, import_jsx_runtime10.jsx)("use", { xlinkHref: "#icon-chevron-right" }) })
        ] })
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime10.jsx)("div", { className: "fullwidth-teaser-content", children: /* @__PURE__ */ (0, import_jsx_runtime10.jsx)("p", { children: titleContent }) }),
      /* @__PURE__ */ (0, import_jsx_runtime10.jsx)("div", { className: "fullwidth-teaser-footer", children: /* @__PURE__ */ (0, import_jsx_runtime10.jsx)("a", { href: "#", "aria-label": footerMsg, className: "btn btn-primary btn-block d-xl-none", children: btnMsg }) })
    ] })
  ] });
}

// src/components/Hero/index.tsx
var import_elements_min6 = require("epfl-elements/dist/css/elements.min.css");
var import_jsx_runtime11 = require("react/jsx-runtime");
function Hero({ title, content, image }) {
  return /* @__PURE__ */ (0, import_jsx_runtime11.jsxs)("div", { className: "container-full", children: [
    /* @__PURE__ */ (0, import_jsx_runtime11.jsxs)("div", { className: "hero", children: [
      /* @__PURE__ */ (0, import_jsx_runtime11.jsxs)("div", { className: "hero-content-container", children: [
        /* @__PURE__ */ (0, import_jsx_runtime11.jsx)("h1", { className: "hero-title", children: title }),
        /* @__PURE__ */ (0, import_jsx_runtime11.jsx)("div", { className: "hero-content", children: content })
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime11.jsx)("div", { className: "hero-img", children: /* @__PURE__ */ (0, import_jsx_runtime11.jsxs)("picture", { children: [
        /* @__PURE__ */ (0, import_jsx_runtime11.jsx)("source", { media: "(min-width: 1140px)", srcSet: `${image} 1x,${image} 2x` }),
        /* @__PURE__ */ (0, import_jsx_runtime11.jsx)("source", { media: "(min-width: 960px)", srcSet: `${image} 1x,${image} 2x` }),
        /* @__PURE__ */ (0, import_jsx_runtime11.jsx)("source", { media: "(min-width: 720px)", srcSet: `${image} 1x,${image} 2x` }),
        /* @__PURE__ */ (0, import_jsx_runtime11.jsx)("source", { media: "(min-width: 541px)", srcSet: `${image} 1x,${image} 2x` }),
        /* @__PURE__ */ (0, import_jsx_runtime11.jsx)("source", { media: "(max-width: 540px)", srcSet: `${image} 1x,${image} 2x` }),
        /* @__PURE__ */ (0, import_jsx_runtime11.jsx)("img", { src: image, alt: "School of Engineering", className: "img-fluid" })
      ] }) })
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime11.jsx)("div", { className: "mt-5", children: "\xA0" })
  ] });
}

// src/components/Loader/index.tsx
var import_elements_min7 = require("epfl-elements/dist/css/elements.min.css");
var import_jsx_runtime12 = require("react/jsx-runtime");
function Loader({ message }) {
  return /* @__PURE__ */ (0, import_jsx_runtime12.jsxs)(
    "div",
    {
      style: {
        width: "100%",
        height: "20px",
        textAlign: "center",
        marginTop: "1em"
      },
      children: [
        /* @__PURE__ */ (0, import_jsx_runtime12.jsx)("span", { className: "loader" }),
        " ",
        /* @__PURE__ */ (0, import_jsx_runtime12.jsx)("small", { children: message || "Loading" })
      ]
    }
  );
}

// src/components/Logo/index.tsx
var import_elements_min8 = require("epfl-elements/dist/css/elements.min.css");
var import_jsx_runtime13 = require("react/jsx-runtime");
var baseUrl = "https://www.epfl.ch/";
var logoUrl = `${baseUrl}/campus/services/website//wp-content/themes/wp-theme-2018/assets/svg/epfl-logo.svg`;
function Logo() {
  return /* @__PURE__ */ (0, import_jsx_runtime13.jsx)("a", { className: "logo", href: `${baseUrl}en/`, children: /* @__PURE__ */ (0, import_jsx_runtime13.jsx)(
    "img",
    {
      src: `${logoUrl}?refresh=now`,
      alt: "Logo EPFL, \xC9cole polytechnique f\xE9d\xE9rale de Lausanne",
      className: "img-fluid"
    }
  ) });
}

// src/components/Metabox/index.css
styleInject(".metabox tbody td,\n.semaineDeRef tbody td,\n.metabox tfoot td,\n.semaineDeRef tfoot td {\n  background-color: rgb(230, 230, 230);\n}\n");

// src/components/Metabox/index.tsx
var import_elements_min9 = require("epfl-elements/dist/css/elements.min.css");
var import_jsx_runtime14 = require("react/jsx-runtime");
function Metabox({
  eventTitle,
  metaboxDetails,
  onClickFn,
  labelButton,
  organizer
}) {
  const getOrganizer = () => (
    //Get data of organizer
    (organizer || []).map(
      (item) => /* @__PURE__ */ (0, import_jsx_runtime14.jsxs)("div", { className: "mt-3", children: [
        /* @__PURE__ */ (0, import_jsx_runtime14.jsx)("p", { className: "mb-2", children: item.label }),
        /* @__PURE__ */ (0, import_jsx_runtime14.jsxs)("div", { className: "avatar-teaser", children: [
          /* @__PURE__ */ (0, import_jsx_runtime14.jsx)("a", { className: "avatar-teaser-img", href: item.link, children: /* @__PURE__ */ (0, import_jsx_runtime14.jsx)("img", { src: item.srcImage, alt: item.altImage }) }),
          /* @__PURE__ */ (0, import_jsx_runtime14.jsx)("div", { className: "avatar-teaser-body", children: /* @__PURE__ */ (0, import_jsx_runtime14.jsx)("p", { children: item.personName }) })
        ] })
      ] })
    )
  );
  const getButtonAction = () => /* @__PURE__ */ (0, import_jsx_runtime14.jsx)("div", { className: "mt-auto align-self-end", children: /* @__PURE__ */ (0, import_jsx_runtime14.jsx)("button", { className: "btn btn-primary", onClick: () => onClickFn && onClickFn(), children: labelButton }) });
  const getMetaboxDetails = () => (
    //Get Content of Metabox Table
    /* @__PURE__ */ (0, import_jsx_runtime14.jsx)(import_jsx_runtime14.Fragment, { children: /* @__PURE__ */ (0, import_jsx_runtime14.jsx)("div", { className: "border col-md-5 bg-gray-100", children: /* @__PURE__ */ (0, import_jsx_runtime14.jsxs)("div", { className: "d-flex flex-column py-3 bg-gray-20", children: [
      /* @__PURE__ */ (0, import_jsx_runtime14.jsx)("h4", { children: eventTitle }),
      /* @__PURE__ */ (0, import_jsx_runtime14.jsx)("table", { className: "table h-100 metabox", children: /* @__PURE__ */ (0, import_jsx_runtime14.jsx)("tbody", {
        /* 
            Get data to fill the table.
            If there is a link map, then it will put the data in <a> tag inside <td> tag
            If not, it puts the data in the <td> tag
        */
        children: (metaboxDetails || []).map(
          (item, i) => item.key && /* @__PURE__ */ (0, import_jsx_runtime14.jsxs)("tr", { children: [
            /* @__PURE__ */ (0, import_jsx_runtime14.jsx)("td", { children: item.key }),
            item.link ? /* @__PURE__ */ (0, import_jsx_runtime14.jsx)("td", { children: /* @__PURE__ */ (0, import_jsx_runtime14.jsx)("a", { href: item.link, children: item.value }) }, i) : /* @__PURE__ */ (0, import_jsx_runtime14.jsx)("td", { children: item.value }, i)
          ] })
        )
      }) }),
      getOrganizer(),
      getButtonAction()
    ] }) }) })
  );
  return /* @__PURE__ */ (0, import_jsx_runtime14.jsxs)(import_jsx_runtime14.Fragment, { children: [
    metaboxDetails && getMetaboxDetails(),
    !metaboxDetails && console.error("The component must have the metaboxDetails array to work")
  ] });
}

// src/components/Table/index.tsx
var import_react5 = require("react");
var import_sort_objects_array = __toESM(require("sort-objects-array"), 1);

// src/components/Tag/index.tsx
var import_elements_min10 = require("epfl-elements/dist/css/elements.min.css");

// src/components/Tag/style.css
styleInject(".tag .remove {\n  text-decoration: none;\n  float: right;\n  font-size: 1.25em;\n  line-height: 0.5em;\n  margin-top: 0.1em !important;\n  margin-left: 0.3em;\n  color: inherit;\n}\n");

// src/components/Tag/index.tsx
var import_jsx_runtime15 = require("react/jsx-runtime");
function Tag({ id, label, href, className, removable, removeCallback }) {
  const classNameToUse = className ? `tag ${className}` : "tag tag-primary";
  function removeTag() {
    if (removeCallback) {
      removeCallback(label);
    }
  }
  const getTag = () => /* @__PURE__ */ (0, import_jsx_runtime15.jsxs)("a", { id: String(id), href: href || `#${String(id)}`, className: classNameToUse, children: [
    label,
    removable && /* @__PURE__ */ (0, import_jsx_runtime15.jsx)("a", { href: `#${String(id)}`, onClick: () => removeTag(), className: "remove", tabIndex: -1, title: "Remove", children: "\xD7" })
  ] });
  return /* @__PURE__ */ (0, import_jsx_runtime15.jsx)(import_jsx_runtime15.Fragment, { children: label && getTag() });
}

// src/components/Table/index.tsx
var import_elements_min11 = require("epfl-elements/dist/css/elements.min.css");

// src/components/Table/index.css
styleInject('.table {\n  overflow-y: scroll;\n  height: 600px;\n  display: block;\n}\n.table th {\n  background: white;\n  position: sticky;\n  top: 0;\n}\n.table tr:nth-child(even) {\n  background: #f8f8f8;\n}\n.table th .aligner {\n  display: flex;\n  align-items: center;\n}\n.table-sortable thead th .tablesaw-sortable-arrow {\n  display: block;\n  float: left;\n  height: 1rem;\n  position: relative;\n  width: 1rem;\n}\n.table-sortable thead th .tablesaw-sortable-arrow:before {\n  content: " ";\n  display: inline-block;\n  position: absolute;\n  bottom: 0;\n  left: 0;\n  width: 0;\n  height: 0;\n  border-left: 0.29rem solid transparent;\n  border-right: 0.29rem solid transparent;\n  border-top: 0.35rem solid #d5d5d5;\n  margin: 0;\n}\n.table-sortable thead th .tablesaw-sortable-arrow:after {\n  content: " ";\n  position: absolute;\n  display: inline-block;\n  top: 0;\n  left: 0;\n  width: 0;\n  height: 0;\n  border-left: 0.29rem solid transparent;\n  border-right: 0.29rem solid transparent;\n  border-bottom: 0.35rem solid #d5d5d5;\n  margin: 0;\n}\n');

// src/components/Table/index.tsx
var import_jsx_runtime16 = require("react/jsx-runtime");
function Table({ data, title, columns, columnsLabels, hyperLinks, tagColumns, showRowTotals, columnsWithRawHtml, width, height, orderCallbackFn }) {
  const [cols, setCols] = (0, import_react5.useState)();
  const [rows, setRows] = (0, import_react5.useState)();
  const [asc, setAsc] = (0, import_react5.useState)(false);
  function orderByColumn(col) {
    setRows(void 0);
    const direction = asc ? void 0 : "desc";
    const sortedData = (0, import_sort_objects_array.default)(data, col, direction);
    setRows(sortedData);
    setAsc(!asc);
    if (orderCallbackFn) {
      orderCallbackFn({ column: col, order: asc ? "ascend" : "descend", data: rows });
    }
  }
  function getColumns() {
    if (columns) {
      return columns;
    }
    if (data && data.length > 0) {
      return Object.keys(data[0]);
    }
  }
  (0, import_react5.useEffect)(() => {
    setRows([]);
    setCols(getColumns());
    setRows(data);
    setAsc(true);
  }, [data]);
  const getColumnLabel = (col, i) => columnsLabels && columnsLabels[i] ? columnsLabels[i] : col;
  const getHyperLinkRowValue = (col, row) => {
    const filtered = (hyperLinks || []).filter((x) => x.column === col);
    if (filtered.length > 0) {
      return /* @__PURE__ */ (0, import_jsx_runtime16.jsx)("a", { href: row[filtered[0].link], target: filtered[0].target, onClick: filtered[0].onClick, children: row[col] });
    }
  };
  const getTagValue = (col, row) => {
    const filtered = tagColumns.columns.filter((x) => x === col);
    if (filtered.length > 0) {
      const tags = (row[filtered[0]] || "").split(tagColumns.separator);
      return /* @__PURE__ */ (0, import_jsx_runtime16.jsx)("div", { children: tags.map((tag, i) => /* @__PURE__ */ (0, import_jsx_runtime16.jsx)(Tag, { id: i, label: tag }, i)) });
    }
  };
  const getRowValue = (col, row) => {
    if (hyperLinks) {
      const hyperlinkValue = getHyperLinkRowValue(col, row);
      if (hyperlinkValue) {
        return hyperlinkValue;
      }
    }
    if (tagColumns) {
      const tagValue = getTagValue(col, row);
      if (tagValue) {
        return tagValue;
      }
    }
    if (columnsWithRawHtml && columnsWithRawHtml.includes(col)) {
      return /* @__PURE__ */ (0, import_jsx_runtime16.jsx)("span", { dangerouslySetInnerHTML: { __html: row[col] } });
    }
    return row[col];
  };
  const getHeader = () => /* @__PURE__ */ (0, import_jsx_runtime16.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime16.jsx)("tr", { children: (cols || []).map((col, i) => /* @__PURE__ */ (0, import_jsx_runtime16.jsx)("th", { onClick: () => orderByColumn(col), children: /* @__PURE__ */ (0, import_jsx_runtime16.jsxs)("div", { className: "aligner", children: [
    /* @__PURE__ */ (0, import_jsx_runtime16.jsx)("div", { children: /* @__PURE__ */ (0, import_jsx_runtime16.jsx)("span", { className: "tablesaw-sortable-arrow" }) }),
    /* @__PURE__ */ (0, import_jsx_runtime16.jsx)("div", { children: /* @__PURE__ */ (0, import_jsx_runtime16.jsx)("button", { className: "tablesaw-sortable-btn", children: getColumnLabel(col, i) }) })
  ] }) }, `col-${i}`)) }) });
  const getRows = () => /* @__PURE__ */ (0, import_jsx_runtime16.jsx)("tbody", { children: (rows || []).map((row, i) => /* @__PURE__ */ (0, import_jsx_runtime16.jsx)("tr", { children: (cols || []).map((col, j) => /* @__PURE__ */ (0, import_jsx_runtime16.jsx)("td", { children: getRowValue(col, row) }, `cell-${i}-${j}`)) }, `row-${i}`)) });
  const getTable = () => /* @__PURE__ */ (0, import_jsx_runtime16.jsxs)("div", { children: [
    title && /* @__PURE__ */ (0, import_jsx_runtime16.jsxs)(import_jsx_runtime16.Fragment, { children: [
      /* @__PURE__ */ (0, import_jsx_runtime16.jsx)("hr", {}),
      /* @__PURE__ */ (0, import_jsx_runtime16.jsx)("h4", { children: title }),
      /* @__PURE__ */ (0, import_jsx_runtime16.jsx)("hr", {})
    ] }),
    rows && showRowTotals && /* @__PURE__ */ (0, import_jsx_runtime16.jsxs)("h5", { children: [
      "Total Records: ",
      rows.length
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime16.jsxs)("table", { className: "table table-sortable", style: { width, height }, children: [
      cols && getHeader(),
      cols && rows && getRows()
    ] })
  ] });
  return /* @__PURE__ */ (0, import_jsx_runtime16.jsx)(import_jsx_runtime16.Fragment, { children: rows && cols && getTable() });
}

// src/components/Tagset/index.tsx
var import_react6 = require("react");
var import_elements_min12 = require("epfl-elements/dist/css/elements.min.css");

// src/components/Tagset/styles.css
styleInject(".tagset-wrapper {\n  background-color: #eee;\n  width: 100%;\n  min-height: 40px;\n  padding: 0.5em;\n  border: 1px solid #ccc;\n}\n.add-tag {\n  border: 0px;\n  background-color: #eee;\n}\n.add-tag-separator {\n  border-top: 1px solid #ddd;\n}\n.grid-container {\n  display: grid;\n  grid-template-columns: auto auto auto auto;\n  gap: 10px;\n}\n.grid-container > div {\n  text-align: center;\n}\n");

// src/components/Tagset/index.tsx
var import_jsx_runtime17 = require("react/jsx-runtime");
function Tagset({
  tags = [],
  callbackFn,
  className,
  addLabel = "Add new tag",
  tagSpacing = "2px",
  addNewPosition = "bottom",
  showInColumns = false,
  disableEdit = false
}) {
  const inputRef = (0, import_react6.useRef)(null);
  const [localTags, setLocalTags] = (0, import_react6.useState)(tags);
  function updateTagset(updatedTags, mutationOperation) {
    if (callbackFn) {
      callbackFn({
        tags: updatedTags,
        operation: mutationOperation
      });
    }
    setLocalTags(updatedTags);
  }
  function handleChange(event) {
    if (event.key === "Enter") {
      handleUpdate(event.target.value);
      inputRef.current.value = "";
    }
  }
  function handleDelete(tagLabel) {
    const updatedTags = localTags.filter((tag) => tag.label !== tagLabel);
    const mutationOperation = {
      operation: "delete",
      label: tagLabel
    };
    updateTagset(updatedTags, mutationOperation);
  }
  function handleUpdate(tagLabel) {
    const checkTags = localTags.filter((tag) => tag.label === tagLabel);
    if (checkTags.length > 0) {
      return;
    }
    const mutationOperation = {
      operation: "add",
      label: tagLabel
    };
    const updatedTags = [...localTags, { label: tagLabel, value: tagLabel }];
    updateTagset(updatedTags, mutationOperation);
  }
  const getAddInput = () => /* @__PURE__ */ (0, import_jsx_runtime17.jsx)(
    "input",
    {
      type: "text",
      className: "add-tag",
      ref: inputRef,
      placeholder: addLabel,
      onKeyDown: handleChange
    }
  );
  const getTag = (tag, i) => {
    if (showInColumns) {
      return /* @__PURE__ */ (0, import_jsx_runtime17.jsx)("div", { children: disableEdit ? /* @__PURE__ */ (0, import_jsx_runtime17.jsx)(Tag, { label: tag.label, className }, i) : /* @__PURE__ */ (0, import_jsx_runtime17.jsx)(Tag, { label: tag.label, className, removable: true, removeCallback: handleDelete }, i) }, `span-${i}`);
    }
    return /* @__PURE__ */ (0, import_jsx_runtime17.jsx)("span", { style: { marginRight: tagSpacing }, children: disableEdit ? /* @__PURE__ */ (0, import_jsx_runtime17.jsx)(Tag, { label: tag.label, className }, i) : /* @__PURE__ */ (0, import_jsx_runtime17.jsx)(Tag, { label: tag.label, className, removable: true, removeCallback: handleDelete }, i) }, `span-${i}`);
  };
  const getTagSet = () => /* @__PURE__ */ (0, import_jsx_runtime17.jsxs)("div", { className: showInColumns ? "tagset-wrapper grid-container" : "tagset-wrapper", children: [
    !disableEdit && addNewPosition === "top" && [
      getAddInput(),
      /* @__PURE__ */ (0, import_jsx_runtime17.jsx)("hr", { className: "add-tag-separator" })
    ],
    localTags && localTags.map(
      (tag, i) => getTag(tag, i)
    ),
    !disableEdit && addNewPosition === "bottom" && getAddInput()
  ] });
  return /* @__PURE__ */ (0, import_jsx_runtime17.jsx)(import_jsx_runtime17.Fragment, { children: localTags && getTagSet() });
}

// src/components/Video/index.tsx
var import_jsx_runtime18 = require("react/jsx-runtime");
function Video({ src, frameborder, allow }) {
  return /* @__PURE__ */ (0, import_jsx_runtime18.jsx)("div", { className: "embed-responsive embed-responsive-16by9", children: /* @__PURE__ */ (0, import_jsx_runtime18.jsx)("iframe", { className: "embed-responsive-item", src, frameBorder: frameborder, allow }) });
}

// src/components/Card/index.tsx
var import_elements_min13 = require("epfl-elements/dist/css/elements.min.css");
var import_jsx_runtime19 = require("react/jsx-runtime");
function Card({ picture, children, link }) {
  const getPlainCard = () => /* @__PURE__ */ (0, import_jsx_runtime19.jsxs)("div", { className: "card", children: [
    picture && /* @__PURE__ */ (0, import_jsx_runtime19.jsx)("picture", { className: "card-img-top", children: /* @__PURE__ */ (0, import_jsx_runtime19.jsx)("img", { src: picture.src, className: "img-fluid", title: picture.title, alt: picture.alt }) }),
    /* @__PURE__ */ (0, import_jsx_runtime19.jsx)("div", { className: "card-body", children })
  ] });
  const getLinkCard = () => /* @__PURE__ */ (0, import_jsx_runtime19.jsxs)("a", { href: link, className: "card link-trapeze-horizontal", children: [
    picture && /* @__PURE__ */ (0, import_jsx_runtime19.jsx)("picture", { className: "card-img-top", children: /* @__PURE__ */ (0, import_jsx_runtime19.jsx)("img", { src: picture.src, className: "img-fluid", title: picture.title, alt: picture.alt }) }),
    /* @__PURE__ */ (0, import_jsx_runtime19.jsx)("div", { className: "card-body", children })
  ] });
  return /* @__PURE__ */ (0, import_jsx_runtime19.jsxs)(import_jsx_runtime19.Fragment, { children: [
    link && getLinkCard(),
    !link && getPlainCard()
  ] });
}

// src/components/Forms/Button.tsx
var import_jsx_runtime20 = require("react/jsx-runtime");
function Button({ label, onClickFn }) {
  return /* @__PURE__ */ (0, import_jsx_runtime20.jsx)(
    "button",
    {
      className: "btn btn-secondary",
      style: { height: "2.5em" },
      onClick: (e) => onClickFn(e),
      children: label
    }
  );
}

// src/components/Forms/index.css
styleInject("input[type=checkbox] {\n  filter: saturate(0) opacity(80%) brightness(1.25);\n}\n.checkbox-label {\n  font-size: 0.7em;\n  white-space: nowrap;\n}\n.checkbox-label-md {\n  font-size: 0.8em;\n  white-space: nowrap;\n}\n.checkbox-label-bg {\n  font-size: 1em;\n  white-space: nowrap;\n}\n.checkbox-group-label {\n  margin-bottom: 4px;\n}\n.checkbox-container {\n  max-width: 600px;\n  max-height: 230px;\n  overflow-y: auto;\n}\n.checkbox-container-no-max-height {\n  max-width: 600px;\n}\n.checkbox-container-no-max-width {\n  max-height: 230px;\n  overflow-y: auto;\n}\n.checkboxgroup-wrapper {\n  padding: 2em;\n  line-height: 1.2;\n}\n.checkboxgroup-wrapper-small {\n  padding: 1em;\n  line-height: 1.2;\n}\n.checkboxgroup-wrapper-no-padding {\n  padding: 0em;\n  line-height: 1.2;\n}\n@media only screen and (min-width: 780px) {\n  .custom-switch .custom-control-label:after {\n    top: calc(0.3rem + 2px) !important;\n  }\n}\n");

// src/components/Forms/Checkbox.tsx
var import_jsx_runtime21 = require("react/jsx-runtime");
function Checkbox({ label, isSelected, checkboxLabelClass, onCheckboxChange }) {
  return /* @__PURE__ */ (0, import_jsx_runtime21.jsx)("div", { className: "form-check", children: /* @__PURE__ */ (0, import_jsx_runtime21.jsxs)("label", { className: "form-check-label", children: [
    /* @__PURE__ */ (0, import_jsx_runtime21.jsx)(
      "input",
      {
        type: "checkbox",
        name: label,
        checked: isSelected,
        onChange: (e) => onCheckboxChange(e),
        className: "form-check-input"
      }
    ),
    /* @__PURE__ */ (0, import_jsx_runtime21.jsx)("span", { className: checkboxLabelClass || "checkbox-label", children: label })
  ] }) });
}

// src/components/Forms/CheckboxGroup.tsx
var import_react7 = require("react");
var import_jsx_runtime22 = require("react/jsx-runtime");
function CheckboxGroup({ onChangeFn, title, options, labels, unchecked = [], wrapperClass, containerClass, checkboxLabelClass }) {
  const [allState, setAllState] = (0, import_react7.useState)(true);
  const [groupState, setGroupState] = (0, import_react7.useState)((options || []).reduce(
    (options2, option) => ({
      ...options2,
      [option]: !unchecked.includes(option)
    }),
    {}
  ));
  const isFirstRender = (0, import_react7.useRef)(true);
  (0, import_react7.useEffect)(() => {
    if (isFirstRender.current) {
      isFirstRender.current = false;
      return;
    }
    const currentSelected = allState === true ? ["ALL", ...Object.keys(groupState)] : Object.keys(groupState).filter((x) => groupState[x] === true);
    onChangeFn(currentSelected);
  }, [allState, groupState]);
  (0, import_react7.useEffect)(() => {
    Object.keys(groupState).filter((x) => !groupState[x]).length > 0 ? setAllState(false) : setAllState(true);
  }, [allState, groupState]);
  const handleCheckboxChange = (changeEvent) => {
    const { name } = changeEvent.target;
    const realName = labels && labels.includes(name) ? options[labels.indexOf(name)] : name;
    setGroupState({
      ...groupState,
      [realName]: !groupState[realName]
    });
  };
  const changeAllCheckBoxes = (newState) => {
    setGroupState((options || []).reduce(
      (options2, option) => ({
        ...options2,
        [option]: newState
      }),
      {}
    ));
  };
  const handleToggleAll = () => {
    changeAllCheckBoxes(!allState);
    setAllState(!allState);
  };
  const getOptionLabel = (option, i) => {
    if (!labels || !Array.isArray(labels)) {
      return option;
    }
    if (labels[i]) {
      return labels[i];
    }
    return option;
  };
  return /* @__PURE__ */ (0, import_jsx_runtime22.jsxs)("div", { className: wrapperClass || "checkboxgroup-wrapper", children: [
    /* @__PURE__ */ (0, import_jsx_runtime22.jsx)("div", { className: "checkbox-group-label", children: /* @__PURE__ */ (0, import_jsx_runtime22.jsx)("span", { style: { fontSize: "0.8em", fontWeight: "bold" }, children: title }) }),
    /* @__PURE__ */ (0, import_jsx_runtime22.jsxs)("div", { className: containerClass || "checkbox-container", children: [
      /* @__PURE__ */ (0, import_jsx_runtime22.jsx)(Checkbox, { label: "All", isSelected: allState, onCheckboxChange: handleToggleAll, checkboxLabelClass }),
      options && options.map(
        (option, i) => /* @__PURE__ */ (0, import_jsx_runtime22.jsx)(
          Checkbox,
          {
            isSelected: allState ? true : groupState[option],
            onCheckboxChange: handleCheckboxChange,
            label: getOptionLabel(option, i),
            checkboxLabelClass
          },
          `option-${i}`
        )
      )
    ] })
  ] });
}

// src/components/Forms/Csfrtoken.tsx
var import_react8 = require("react");
var import_js_cookie = __toESM(require("js-cookie"), 1);
var import_jsx_runtime23 = require("react/jsx-runtime");
function CsfrToken({ tokenName = "csrftoken", inputName = "csrfmiddlewaretoken" }) {
  const [token, setToken] = (0, import_react8.useState)();
  (0, import_react8.useEffect)(() => {
    const cookietoken = import_js_cookie.default.get(tokenName);
    setToken(cookietoken);
  }, []);
  const getTokenInput = () => /* @__PURE__ */ (0, import_jsx_runtime23.jsx)(
    "input",
    {
      type: "hidden",
      name: inputName,
      value: token
    }
  );
  return /* @__PURE__ */ (0, import_jsx_runtime23.jsx)(import_jsx_runtime23.Fragment, { children: token && getTokenInput() });
}

// src/components/Forms/Dropdown.tsx
var import_react9 = require("react");
var import_jsx_runtime24 = require("react/jsx-runtime");
function Dropdown({ label, options, onChangeFn, placeholder }) {
  const [showDropdown, setShowDropdown] = (0, import_react9.useState)(false);
  const [activeOption, setActiveOption] = (0, import_react9.useState)(options.filter((x) => x.active)[0]?.option || "");
  const dropdownRef = (0, import_react9.useRef)(null);
  function localOnChange(e) {
    const selectedOption = e.target.innerText;
    setActiveOption(selectedOption);
    setShowDropdown(false);
    onChangeFn(selectedOption);
    e.preventDefault();
  }
  const handleClickOutside = (event) => {
    if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
      setShowDropdown(false);
    }
  };
  (0, import_react9.useEffect)(() => {
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, [showDropdown]);
  return /* @__PURE__ */ (0, import_jsx_runtime24.jsxs)("div", { className: "dropdown", ref: dropdownRef, children: [
    /* @__PURE__ */ (0, import_jsx_runtime24.jsxs)(
      "button",
      {
        className: "btn btn-sm btn-secondary dropdown-toggle",
        type: "button",
        id: "dropdownMenuButton",
        "data-toggle": "dropdown",
        onClick: () => setShowDropdown(!showDropdown),
        "aria-haspopup": "true",
        "aria-expanded": "false",
        children: [
          label,
          " ",
          activeOption ? activeOption : placeholder || "Select an option"
        ]
      }
    ),
    /* @__PURE__ */ (0, import_jsx_runtime24.jsx)(
      "div",
      {
        className: "dropdown-menu",
        "aria-labelledby": "dropdownMenuButton",
        style: { display: showDropdown ? "block" : "none" },
        children: (options || []).map((item, i) => /* @__PURE__ */ (0, import_jsx_runtime24.jsx)(
          "a",
          {
            className: "dropdown-item",
            style: {
              fontSize: "0.92em"
            },
            onClick: localOnChange,
            href: "#",
            children: item.option
          },
          `option-${i}`
        ))
      }
    )
  ] });
}

// src/components/Forms/Input.tsx
var import_jsx_runtime25 = require("react/jsx-runtime");
function Input({ placeholder, onChangeFn, type = "text" }) {
  return /* @__PURE__ */ (0, import_jsx_runtime25.jsx)(
    "input",
    {
      type,
      className: "form-control",
      style: { fontSize: "0.95rem" },
      placeholder,
      onChange: (e) => onChangeFn(e)
    }
  );
}

// src/components/Filterbox/index.tsx
var import_react10 = require("react");
var import_jsx_runtime26 = require("react/jsx-runtime");
function filter(array, predicate) {
  let index = -1;
  let resIndex = 0;
  const length = array == null ? 0 : array.length;
  const result = [];
  while (++index < length) {
    const value = (array || [])[index];
    if (predicate(value, index, array)) {
      result[resIndex++] = value;
    }
  }
  return result;
}
function FilterBox({
  data,
  filterFields = [],
  filterLabels = [],
  disabledOptions = {},
  searchbox,
  updateFn,
  checkboxLabelClass
}) {
  const [boxfilters, setboxFilters] = (0, import_react10.useState)({});
  const [filteredCopy, setFilteredCopy] = (0, import_react10.useState)(null);
  function setLocalData() {
    if (Object.keys(boxfilters).length === 0) {
      return;
    }
    const filters = filter(
      filterFields,
      (x) => boxfilters[x]
    ).map(
      (field) => (val) => {
        return boxfilters[`${field}`].includes("ALL") || boxfilters[`${field}`].includes(val[`${field}`]);
      }
    );
    const filteredData = filter(data, (item) => {
      const testResults = filters.map((fn) => fn(item));
      return !testResults.includes(false);
    });
    updateFn(filteredData);
    setFilteredCopy(filteredData);
  }
  function filterCheck(searchFields, item, value) {
    const testResults = searchFields.map((field) => String(item[field]).toLowerCase().includes(value)).filter((x) => x);
    return testResults.length > 0;
  }
  function searchLocal(value) {
    const dataToSearch = filteredCopy || data;
    const lowerValue = value.toLowerCase();
    const filteredData = filter(dataToSearch, (item) => filterCheck(searchbox.fields, item, lowerValue));
    updateFn(filteredData);
  }
  (0, import_react10.useEffect)(() => {
    boxfilters && setLocalData();
  }, [boxfilters]);
  const getFilterOptions = (field) => Array.from(new Set((data || []).map((i) => i[field]))).filter((x) => x).sort();
  const getFilterBox = () => /* @__PURE__ */ (0, import_jsx_runtime26.jsxs)("div", { className: "row", style: { backgroundColor: "rgb(250 250 250)", verticalAlign: "top", margin: "1em" }, children: [
    filterFields.map(
      (field, i) => /* @__PURE__ */ (0, import_jsx_runtime26.jsx)(
        CheckboxGroup,
        {
          id: field,
          title: filterLabels[i] || field,
          onChangeFn: (vals) => setboxFilters({
            ...boxfilters,
            [field]: vals
          }),
          options: getFilterOptions(field),
          unchecked: disabledOptions[field],
          checkboxLabelClass
        },
        field
      )
    ),
    searchbox && /* @__PURE__ */ (0, import_jsx_runtime26.jsxs)("div", { className: "checkboxgroup-wrapper", children: [
      /* @__PURE__ */ (0, import_jsx_runtime26.jsx)("span", { style: { fontSize: "0.8em", fontWeight: "bold" }, children: searchbox.label }),
      /* @__PURE__ */ (0, import_jsx_runtime26.jsx)(
        Input,
        {
          placeholder: "Type to filter the results...",
          onChangeFn: (e) => searchLocal(e.target.value)
        }
      )
    ] })
  ] }, "row-checkboxes");
  return /* @__PURE__ */ (0, import_jsx_runtime26.jsx)("div", { children: data && filterFields && getFilterBox() });
}

// src/components/Forms/Range.tsx
var import_react11 = require("react");
var import_elements_min14 = require("epfl-elements/dist/css/elements.min.css");

// src/components/Forms/Range.css
styleInject("input[type=range] {\n  width: 100%;\n  height: 7px;\n  background: rgba(170, 170, 170, 0.6);\n  border-radius: 5px;\n  background-image: linear-gradient(#ff4500, #ff4500);\n  background-repeat: no-repeat;\n}\n");

// src/components/Forms/Range.tsx
var import_jsx_runtime27 = require("react/jsx-runtime");
function Range({
  minInput,
  maxInput,
  defaultValue,
  setInput,
  label,
  labelValue
}) {
  const calculateRangeStyle = (value, minInput2, maxInput2) => `${(value - minInput2) * 100 / (maxInput2 - minInput2)}% 100%`;
  const [currentValue, setCurrentValue] = (0, import_react11.useState)(defaultValue);
  const [rangeStyle, setRangeStyle] = (0, import_react11.useState)(calculateRangeStyle(defaultValue, minInput, maxInput));
  const onInputValue = (event) => {
    const valueOnInput = Number(event.target.value);
    const maxOnInput = Number(event.target.max);
    const minOnInput = Number(event.target.min);
    const currentStyleValue = calculateRangeStyle(valueOnInput, minOnInput, maxOnInput);
    setCurrentValue(valueOnInput);
    setRangeStyle(currentStyleValue);
  };
  const rangeSlider = () => /* @__PURE__ */ (0, import_jsx_runtime27.jsxs)("div", { className: "form-group custom-control", children: [
    /* @__PURE__ */ (0, import_jsx_runtime27.jsx)("label", { htmlFor: "rangeInput", children: label }),
    /* @__PURE__ */ (0, import_jsx_runtime27.jsx)("input", { type: "range", name: "range", className: "form-control-range custom-range", min: minInput, max: maxInput, value: currentValue, step: setInput, style: { backgroundSize: rangeStyle }, id: "rangeInput", onInput: onInputValue }),
    /* @__PURE__ */ (0, import_jsx_runtime27.jsxs)("span", { className: "output", children: [
      labelValue,
      /* @__PURE__ */ (0, import_jsx_runtime27.jsx)("strong", { children: /* @__PURE__ */ (0, import_jsx_runtime27.jsx)("output", { htmlFor: "rangeInput", id: "rangeOutput", "aria-hidden": "true", children: currentValue }) })
    ] })
  ] });
  return /* @__PURE__ */ (0, import_jsx_runtime27.jsx)(import_jsx_runtime27.Fragment, { children: rangeSlider() });
}

// src/components/Forms/Switch.tsx
var import_react12 = require("react");
var import_jsx_runtime28 = require("react/jsx-runtime");
function Switch({ id, label, isChecked, marginLeft, onChangeCallback }) {
  const [isCheckedLocal, setIsCheckedLocal] = (0, import_react12.useState)(Boolean(isChecked));
  const idToUse = id ? id : Date.now().toString(30);
  function localChangeCallback(e) {
    if (onChangeCallback) {
      onChangeCallback(e.target.checked);
    }
    setIsCheckedLocal(!isCheckedLocal);
  }
  return /* @__PURE__ */ (0, import_jsx_runtime28.jsxs)("div", { className: "custom-control custom-switch", style: { marginLeft: marginLeft ? marginLeft : "1em" }, children: [
    /* @__PURE__ */ (0, import_jsx_runtime28.jsx)(
      "input",
      {
        type: "checkbox",
        className: "custom-control-input",
        id: idToUse,
        checked: isCheckedLocal,
        onChange: localChangeCallback
      }
    ),
    /* @__PURE__ */ (0, import_jsx_runtime28.jsx)("label", { className: "custom-control-label", htmlFor: id, children: label })
  ] });
}

// src/components/navigations/asidemenu.tsx
var import_react_router_dom = require("react-router-dom");
var import_elements_min15 = require("epfl-elements/dist/css/elements.min.css");
var import_jsx_runtime29 = require("react/jsx-runtime");
function Asidemenu({ isHome, isLoading, menuItems, homeAnchor, homeLink, feedBackEmail, useReactRouterLinks }) {
  const getMenuList = (menus) => menus.map(
    (menu) => /* @__PURE__ */ (0, import_jsx_runtime29.jsx)("li", { className: menu.link === document.location.pathname ? "active" : void 0, children: useReactRouterLinks ? /* @__PURE__ */ (0, import_jsx_runtime29.jsx)(import_react_router_dom.Link, { to: menu.link, children: menu.anchor }) : /* @__PURE__ */ (0, import_jsx_runtime29.jsx)("a", { href: menu.link, children: menu.anchor }) }, menu.link)
  );
  function getMenuItems() {
    return (menuItems || []).map(
      (item) => /* @__PURE__ */ (0, import_jsx_runtime29.jsxs)("li", { children: [
        /* @__PURE__ */ (0, import_jsx_runtime29.jsx)("a", { children: item.heading }),
        " ",
        /* @__PURE__ */ (0, import_jsx_runtime29.jsxs)("ul", { children: [
          item.menus && getMenuList(item.menus),
          item.submenus && item.submenus.map(
            (submenu) => /* @__PURE__ */ (0, import_jsx_runtime29.jsxs)("li", { children: [
              /* @__PURE__ */ (0, import_jsx_runtime29.jsx)("a", { children: submenu.heading }),
              " ",
              /* @__PURE__ */ (0, import_jsx_runtime29.jsx)("ul", { children: getMenuList(submenu.menus) })
            ] }, submenu.heading)
          )
        ] })
      ] }, item.heading)
    );
  }
  return /* @__PURE__ */ (0, import_jsx_runtime29.jsxs)("aside", { className: "nav-aside-wrapper", children: [
    /* @__PURE__ */ (0, import_jsx_runtime29.jsxs)("nav", { id: "nav-aside", className: "nav-aside", role: "navigation", "aria-describedby": "nav-aside-title", children: [
      /* @__PURE__ */ (0, import_jsx_runtime29.jsx)("h2", { className: "h5 sr-only-xl", children: "On the same topic" }),
      /* @__PURE__ */ (0, import_jsx_runtime29.jsxs)("ul", { children: [
        !isLoading && /* @__PURE__ */ (0, import_jsx_runtime29.jsx)("li", { className: isHome ? "active" : "", children: useReactRouterLinks ? /* @__PURE__ */ (0, import_jsx_runtime29.jsx)(import_react_router_dom.Link, { to: homeLink, children: homeAnchor }) : /* @__PURE__ */ (0, import_jsx_runtime29.jsx)("a", { href: homeLink, children: homeAnchor }) }),
        isLoading ? /* @__PURE__ */ (0, import_jsx_runtime29.jsx)(Loader, {}) : getMenuItems()
      ] })
    ] }),
    feedBackEmail && /* @__PURE__ */ (0, import_jsx_runtime29.jsx)("div", { className: "", children: /* @__PURE__ */ (0, import_jsx_runtime29.jsxs)("a", { className: "btn btn-primary btn-block", href: `mailto:${feedBackEmail}`, children: [
      /* @__PURE__ */ (0, import_jsx_runtime29.jsx)("i", { className: "fas fa-bullhorn" }),
      " Provide feedback"
    ] }) })
  ] });
}

// src/components/navigations/index.css
styleInject(".avatar_image {\n  width: 50px;\n  height: 50px;\n  background-size: cover;\n  background-position: top center;\n  border-radius: 50%;\n}\n");

// src/components/navigations/avatar.tsx
var import_jsx_runtime30 = require("react/jsx-runtime");
var stiLogo = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAWUAAAB0CAYAAABdeCMxAAAACXBIWXMAAAsSAAALEgHS3X78AAAO3klEQVR4nO2d0XHrOg6GyZ3TgE8JTgM74xRwH5IS4hKcEpwS7Ld9TUpISkhKiEuwS0hK4B1moXN1YZAiJZEm6f+b4ezdE0sQKQiCQBDUxhgFAACgDP6D+wAAAOUAowwAAAUBowwAAAUBowwAAAUBowwAAAXx6xpuhtZ6pZS6U0rZ/30QfvKtlNrTf78YY74zXyIAAPzQdEqc1nqjlNoqpZaRh35YI22M+Uh0adForY+sH4/GmJdSrq90hPG7L+n+AtDRZPhCa73UWr8rpZ5HGGRFXvW71vo1weUBAICT5oyyNcjWoJJhncqD1vpTa724bK8AANdCi57yq8M7tjHjJ2OM5k0pdWP/RmELzoo8bgAASE5TRpliyCv2z9bQ/jbGWIO8l44zxpzs34wx9zbWqJQ6sZ9Yj3kOzxsAALy05ilv2f8/WEMbk01Bkz/3lJHhOzcAAMxOM0aZ0t542GI95lzWc6ZwRp87xJYBAKlpyVPmYYsDGdexvAneMkIYAICk/FJa/1cp9b+LDbMxf810Ju7FTloAYkMeWusDM8TR6XVa6y5PeiNc355eHpPzZUmOtDjG5jKfXPH0iPMvqA+SjK4vVs5bDXIAKBaj1F/G2qBLNWPUHI1ivqbXPuc695imlNqx6/G1T2uEfHKUUkd2/Ib+3RqurwAZ9jd3sX2hl91zRF/sdT6UJkcYv+ixQEPL0VoKX/BQxeoSGRO0cOUYOTFovUKbDy0tAffJ2lIKYEise0ELYrjH7jv/il4YwcfQV8Gr1npXmhwAaqAloyyFAHY5J+do4crnyFWEiowMj427eCBvPJZnus6hvqwm9mWrtR7M784lB4BaaMYoU9obN8z2gT+SR5kDl9dqMzlu+otW6N+kuHfo0u7+V8A3ne937/w3vSJLHO940Ivs3fFnqS+Pjpfixjf2ueQAUBWtxJQpbrgaiENag7dNFEPeCPJ+PEDPMZ1nzY/bBMREu2aN2sIj406KLw/0RYrtevti5Lh+18TjcslBTBmtptaUUR54YKW2peY0ahFy+UN/DDkvGeYzQxtw/uDJTMekozix6Liez9Axcrycni8lxzN+MMpoRbbmal9Q6hdf+OFiR+1La23sJ3DsZJtyL1zZh6wkpFxqXoIzdKFKaD+l9DFXDFfq/zp0VSSVE+XyHoT+5JIDQFU0WbqTDLNdKn2IPHRHk22dgQ59wHmWxymy1nFnXJ56seEh43QKzW82xhyE+LWrb9xYvo1YhMNj2QthjHLJAaAqmt0OyhosY8wtGecxCyc6DzrEc+YZE1ELG+haNRVFCvKwR7xwBo0yvYQm9UX98xLg1/fnvLnkAFAjze/RRwbviWbv1+SJxnhkIbmw3BBMWd4dSqxRDkEKaYyV4zOWueQAUB1XsUdfR29p7o/nTAspFt1kn+dQG8r49ixV5kYmh1FOwZmxnFA/hB/XH99ccgCojqvezdrGfSlc8NvGccmLdnlsO2nRhSPunGPj1RQyeF+mvFx84ZJccgCojqs2yn1sHJcM9C2FOSSjJy1QuJRRBgA0CIyyAIU5bgXjKk36SQYY3hoAYBQwyg4che4XvDaFI1OiVqPM+zK2HoUaKKWaSw4A1dGEUdZav1NucdfmqoMgpWlJBpfHRKcYmUtyFtsNKV7kwJeRkksOANXRiqfMvaNZ0qLICw55yCcbZa31K71cRq0qnAmpr2PHMsooJ5IDQHW0YpR5xkTu/fS4/DFG9Y7a7lJ1guklNLkvjmXnf86bSw4ANdKKUebLjRcjDeO/IMMe8tBz+cuYAvv02znTxKYg1ZOI9WKl8BEfo1xyAKiKJowyLbflRkzMK46E74RxkCb2qAYFl/8c4a1LXvGl9qCT5Ab3hRbkSHUt+LjlkgNAVbSUfSEVp3kda5jJa+PG0ldkiMtf0vZLXiNjY8lCXPTlUsbFUbVuRX3xjiVNsEq7gJythMwlB4DqaKzIvVQw/iu2sL2jJvNxpPyubvNSkCHVSP6SirW7Nk6N6BM/3jkm9EJzbcYq9WVDxfal3+8uLcfRf9RTRiuytWaUlwM7O29dxog+hbee4727Tffku3YICW3iDs05jbIJ28UlpL0GXFcuOTDKaFW0phaP0CfxvWcBwY5izYY32ipq58hDvqe4daj8sRkA617RpItC/fWN5RB2yfo6YMyyyAGgFlrceeRAS6TnSI06kUEOntG3hpnqZ8TEN+35b0sxyB3U75uBWDrnQGMWuitKNjkA1ECrO490hvFxgnG2NZhvYgwyu4an3q7VkrHpdqC2hiXIE78EVKjpsVdFT3pxnHp9uR0zZrnkAFA6muJtTUOz+V36lKt28oEMwak0jxUAcD1chVEGAIBaQJU4AAAoCBhlAAAoCBhlAAAoCBhlAAAoCBhlAAAoCBhlAAAoCBhlAAAoCBhlAAAoCBhlAAAoCBhlAAAoCBhlAAAoCBhlAAAoCBhlAAAoCBhlAAAoCBhlAAAoCBhlAAAoCBhlAAAoCBhlAAAoCBhlAAAoCBhlAAAoCBjlGdBab7XW71prI7TtWAla6zvHOedszyWNZQ601kc2fpv2e10n13ivYJQnoLVeWaVRSu2UUneOMz1U0RkAQBH8wm0Yh9Z6oZR6V0otBk5wKrUPAIDygKc8nk2AQbYcSu0AAKA84CmPRwpX7I0xT4nlPhpjXhLLaBpjzM21j0EtXOO9gqc8niU78iWDQQYANA6M8nwgTAEAmAyMMgAAFETTRtlmSFAO8auQ1/tFf0PK2kg8Y/s8Rz6pvTckg5//fUr+91yk7r/6R8azR39dqZily1oJY2dl8LDgnH2rQ1eNMc01yoqwiyJMYLO5xg++cVBKbSPO17W7KWNLk4n8nJtc94vG5Y/s3r/bF9lXQP+PY8ZAKbVSSn3GnJ+yYfp/24b2yzWml+r/CH2zY7WacJ+TyWJjeHTcK6eOl36vUuhqc56yfQPTIMW8/ezb2b5FdwkvrQnorf8amA5ox/U9xhOh336Sss9+/qlk6L/9ununBUmh/Oh87FdfTlk9mStymHx8jzm3IKtOXc3ldeVoNDix3ixvzzN4E11rylMmr2PsuC4D5E05P/8ymt1TztD/RaDX5WtB+pFLFveUhTHl7auSe5VMV5vxlHsr7CRsqtqNMUZ3zeb7KqU+hN9uSohXFkrfw/mmcf3dG1ObU+rKofaOKcUSJQ/qQLnZ/N7xbJcc3nKy/vfOL3lde6XULRuDtUPWM3mjJcnqWPZSSb/795Vk2NWvc+Xg16urtXjBAW8uKYb8OfTW83jAQ8cFvcEn9qk0T7lrryOu+2vgGOn+7QaO2Xm8kRSecsr+S3HWEP29E2Km7wXJksbwS5JF3vty4PgS7lVSXc3ycKdu9PaVlGwRItvxQIhhjFhlmdIKNcreh3BAccUJIsf9845/gLKnMsqz998hK0Z/pbCdM3R2YVnee1P6vcqhq62EL6RJh7UxJmjCgJYtv/FzUkikNKSUpbFtzCf/PvB30qehK92J37/uc3MQWkWZs+jT7P2nVDP+t8cI/T0I4yXe25yyPOQqE1ClrrZqlN+MMbEPKr+BC085zmvlZIyR4vBn0MPLcb3k+P3bhxoJItdDnqr/XM8+HMf74E6FS3dzypI4RN7bsVSrq9UbZfJm+WQDV5pB6MbwmxMziXENxD68g8rquH9BD1OPXEZ59v4TZ4YyUo4iJ6R/fQvHJFxOWRK5vmqq1dUWPGXpM2NsHQoYZT8pjNLZGMd6buSp5HjYUxllrsNj9ZePgaS/OWVJ5KoRU62utlC688wojwhddPDjSowpt1a6k9+/KfcuyRLdlJD3xfXMLjKYQ+q/zptTVqNk0dUWPGWuDFM8Jv62vAZFiyFFLHCu+5fDU87R/znhD35OWS5yxJNVzbqKKnEAAFAQMMqgNPB1Amohia62EFPmnylT4op8kHN9al0zc4WMqosne7iZMC9SsqzayaKrLXjKZwo1oSYrn12FsqZnrpdqlR62wyAmecHklNUoWXS1SaM8IZUNRjk/Z3mekUVuXPmjNZEzFRNpn+PJoqvVG2XK++OKFl3rlQZ3rhxOEIjj/sWupKx995jJ+qv+r8NH2l3Dt0tITllNkUtXW5nok+pWxHoAUrm+6NVOYBR8nLeRdUdqN8q8/6sRBes35FQ8UOGbd8c5cspqkeS62qpRVlS4J2iwSMmk+hmY6MsDXwyzCKw/3O0uUbWnZox5E+KVu9C5Efod3z3kW3IqcspqlOS62oRRpgkMPlgreoN7lY0GSipYHVphCkzEcf+2Q9tz0cu0lS28uL512wd5v/hIv6Utj3yFcnLKaoocutpSnvKT4AFYJTtKu+TaQfLsT7YfUTkLTGMv3D973z55iVHaOfg1YK+3ajDG7IV45ZL2w3vm4QHaDXpLdYSlCWrnUvycsholqa62kKf8g31Ta63vqTg4Z0efaCGneqO6p6ViH5q5jdETPagXw3ogWutH8sT6rBL1uUTWtKUZ/7rb0DZloZccUks8p6ymSK2rTa3oI+/2fsKiD+shr2e+LBAIxTsfR4zXRwsxTfo0vp+Q9WP1/j7kKy+nrBZJqavNLbOmwta+TRElDqRgJXvIVwFVwLuPyBG3Xv59K2NjjaUx5nbEnMYbbXga/HLKKatFUulqk7Uv7OeUMca+xX5TrFnKzjjR36wxvnoFKwl7L4wxN+SJSAbj0Nud2GVQqv6ktg4C7Yb85DGab72d2tdjl0vnlNUaKXRV04Z+AFSNXczA4qNr+sQEoCiGdBVV4kArzFlXG4CUeHW1mewLUC80W72kCZBTrIdLy3z/pehIaQQpyKGrMMqgBE6UivWz2klrfaAJqFB4rjnmB0AqkusqwhegBM424QytpUCey+TdzAEIJLmuYqIPXByqUXIUYm1WYT/4RrH0+w21s80saTYcgNnJoaswyqAIaBnv1DoWV72gAeQhta4ifAGKgHI4pyz1PsEggxyk1lUYZVAMtKJyPSKd7YVWmMEggyyk1FWEL0CR0OTJ0hGLU12lrksXUgJgbl2FUQYAgIJA+AIAAAoCRhkAAAoCRhkAAAoCRhkAAAoCRhkAAAoCRhkAAEpBKfU3riL7YBzj4TYAAAAASUVORK5CYII=";
function Avatar({ user = {}, logOutUrl, logoUrl: logoUrl2, logoAltText }) {
  const getBackGroundImage = () => `url('${user.photo_url}')`;
  const avatarLogo = logoUrl2 || stiLogo;
  const avatarLogoAltText = logoAltText || "Logo STI, EPFL school of engineering";
  function handleLogout() {
    if (logOutUrl) {
      window.localStorage.clear();
      window.location.assign(logOutUrl);
    }
  }
  return /* @__PURE__ */ (0, import_jsx_runtime30.jsx)("nav", { className: "nav-lang nav-lang-short ml-auto", children: /* @__PURE__ */ (0, import_jsx_runtime30.jsxs)("div", { className: "avatar-teaser", children: [
    /* @__PURE__ */ (0, import_jsx_runtime30.jsx)("div", { style: { paddingRight: "10px" }, children: /* @__PURE__ */ (0, import_jsx_runtime30.jsx)("img", { className: "avatar-logo", src: avatarLogo, alt: avatarLogoAltText }) }),
    /* @__PURE__ */ (0, import_jsx_runtime30.jsx)(
      "a",
      {
        className: "avatar-teaser-img-placeholder",
        href: `https://people.epfl.ch/${user.sciper}`,
        rel: "noopener noreferrer",
        target: "_blank",
        children: /* @__PURE__ */ (0, import_jsx_runtime30.jsx)("div", { style: { backgroundImage: getBackGroundImage() }, className: "avatar_image" })
      }
    ),
    /* @__PURE__ */ (0, import_jsx_runtime30.jsx)("div", { className: "avatar-teaser-body", children: /* @__PURE__ */ (0, import_jsx_runtime30.jsxs)("p", { children: [
      user.last_name,
      ", ",
      user.first_name
    ] }) }),
    /* @__PURE__ */ (0, import_jsx_runtime30.jsx)("div", { style: { color: "#fff" }, children: /* @__PURE__ */ (0, import_jsx_runtime30.jsx)("a", { className: "btn btn-primary btn-sm", onClick: handleLogout, children: "logout" }) })
  ] }) });
}

// src/components/navigations/language.tsx
var import_jsx_runtime31 = require("react/jsx-runtime");
function Language({ active, enLink, frLink }) {
  return /* @__PURE__ */ (0, import_jsx_runtime31.jsx)("nav", { className: "nav-lang nav-lang-short ml-auto", children: /* @__PURE__ */ (0, import_jsx_runtime31.jsxs)("ul", { children: [
    /* @__PURE__ */ (0, import_jsx_runtime31.jsx)("li", { children: active === "EN" ? /* @__PURE__ */ (0, import_jsx_runtime31.jsx)("a", { href: enLink, "aria-label": "Fran\xE7ais", children: "FR" }) : /* @__PURE__ */ (0, import_jsx_runtime31.jsx)("span", { className: "active", "aria-label": "Fran\xE7ais", children: "FR" }) }),
    /* @__PURE__ */ (0, import_jsx_runtime31.jsx)("li", { children: active === "FR" ? /* @__PURE__ */ (0, import_jsx_runtime31.jsx)("a", { href: frLink, "aria-label": "English", children: "EN" }) : /* @__PURE__ */ (0, import_jsx_runtime31.jsx)("span", { className: "active", "aria-label": "English", children: "EN" }) })
  ] }) });
}

// src/components/navigations/mainMenu.tsx
var import_react13 = require("react");

// src/components/navigations/mainMenuHelpers.tsx
var import_react_router_dom2 = require("react-router-dom");
var import_jsx_runtime32 = require("react/jsx-runtime");
var arrowLeft = "data:image/svg+xml,%0A%3Csvg%20viewBox%3D%220%200%2016%2016%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%3E%0A%20%20%3Cpath%20d%3D%22M4.414%209l5.293%205.293-1.414%201.414L.586%208%208.293.293l1.414%201.414L4.414%207H16v2z%22%20fill-rule%3D%22nonzero%22%2F%3E%0A%3C%2Fsvg%3E%0A";
var chevronRight = "data:image/svg+xml,%0A%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20viewBox%3D%220%200%2024%2024%22%3E%0A%20%20%3Cpath%20fill%3D%22currentColor%22%20d%3D%22M7.1%2017.9l1.9%202%207.9-7.9L9%204.1l-1.9%202L13%2012z%22%2F%3E%0A%3C%2Fsvg%3E%0A";
var childParametersForward = (href, heading, useReactRouterLinks) => /* @__PURE__ */ (0, import_jsx_runtime32.jsxs)(import_jsx_runtime32.Fragment, { children: [
  useReactRouterLinks ? /* @__PURE__ */ (0, import_jsx_runtime32.jsx)(import_react_router_dom2.Link, { to: href, children: heading }) : /* @__PURE__ */ (0, import_jsx_runtime32.jsx)("a", { href, children: heading }),
  /* @__PURE__ */ (0, import_jsx_runtime32.jsx)("a", { role: "button", "aria-hidden": "true", id: heading, className: `forward nav-arrow`, children: /* @__PURE__ */ (0, import_jsx_runtime32.jsx)("div", { className: "icon-container", children: /* @__PURE__ */ (0, import_jsx_runtime32.jsx)("img", { className: "icon", "aria-hidden": "true", src: chevronRight }) }) })
] });
var childParametersBackwards = (href, heading, useReactRouterLinks) => /* @__PURE__ */ (0, import_jsx_runtime32.jsx)(import_jsx_runtime32.Fragment, { children: useReactRouterLinks ? /* @__PURE__ */ (0, import_jsx_runtime32.jsxs)(import_react_router_dom2.Link, { to: href, className: "back", children: [
  /* @__PURE__ */ (0, import_jsx_runtime32.jsx)("img", { className: "icon", "aria-hidden": "true", src: arrowLeft }),
  heading
] }) : /* @__PURE__ */ (0, import_jsx_runtime32.jsxs)("a", { href, className: "back", children: [
  /* @__PURE__ */ (0, import_jsx_runtime32.jsx)("img", { className: "icon", "aria-hidden": "true", src: arrowLeft }),
  heading
] }) });
var itemMenuWithoutChildren = (href, heading, useReactRouterLinks) => /* @__PURE__ */ (0, import_jsx_runtime32.jsx)(import_jsx_runtime32.Fragment, { children: useReactRouterLinks ? /* @__PURE__ */ (0, import_jsx_runtime32.jsx)(import_react_router_dom2.Link, { to: href, children: heading }) : /* @__PURE__ */ (0, import_jsx_runtime32.jsx)("a", { href, children: heading }) });
var findCurrentItem = (level, parent, parentMenus) => {
  const found = level.filter((x) => x.currentItem === true);
  if (found.length > 0) {
    return { found: found[0], items: level, parent, parentMenus };
  }
  let foundDeep;
  for (const item of level) {
    const { menus, link, heading } = item;
    if (menus) {
      foundDeep = findCurrentItem(menus, { heading, link, menus }, level);
      if (foundDeep) {
        return foundDeep;
      }
    }
  }
};
var findMenuDisplay = (forward, backwardsClassName, labelClassName, level, parent, parentMenus) => {
  const found = level.filter((x) => x.heading === labelClassName);
  if (forward && found.length > 0) {
    return { parent: found[0], items: found[0].menus };
  }
  if (found.length > 0) {
    return { found: found[0], items: level, parent, parentMenus };
  }
  let foundDeep;
  for (const item of level) {
    const { menus, link, heading } = item;
    if (menus) {
      foundDeep = findMenuDisplay(forward, backwardsClassName, labelClassName, menus, { heading, link, menus }, level);
      if (foundDeep) {
        return foundDeep;
      }
    }
  }
};
var renderWithParentWithMenus = (values, i, useReactRouterLinks) => {
  return values.currentItem ? /* @__PURE__ */ (0, import_jsx_runtime32.jsx)("li", { className: `current-menu-item menu-item-has-children`, children: childParametersForward(values.link, values.heading, useReactRouterLinks) }, i) : /* @__PURE__ */ (0, import_jsx_runtime32.jsx)("li", { className: `menu-item-has-children`, children: childParametersForward(values.link, values.heading, useReactRouterLinks) }, i);
};
var renderWithParentWithoutMenus = (values, i, useReactRouterLinks) => {
  return values.currentItem ? /* @__PURE__ */ (0, import_jsx_runtime32.jsx)("li", { className: `current-menu-item`, children: itemMenuWithoutChildren(values.link, values.heading, useReactRouterLinks) }, i) : /* @__PURE__ */ (0, import_jsx_runtime32.jsx)("li", { className: ``, children: itemMenuWithoutChildren(values.link, values.heading, useReactRouterLinks) }, i);
};
var renderWithParent = (parent, ancestorOrParentClass, allChildren, useReactRouterLinks) => {
  return (
    //Parent Menu
    /* @__PURE__ */ (0, import_jsx_runtime32.jsxs)("li", { className: `${ancestorOrParentClass} menu-has-item-children`, children: [
      childParametersForward(parent.link, parent.heading, useReactRouterLinks),
      /* @__PURE__ */ (0, import_jsx_runtime32.jsxs)("ul", {
        //Nav back
        children: [
          /* @__PURE__ */ (0, import_jsx_runtime32.jsx)("li", { className: "nav-back", children: childParametersBackwards(parent.link, parent.heading, useReactRouterLinks) }),
          /*
              If children have menus, add property to class
              Same if currentItem is true
          */
          allChildren.map(
            (values, i) => values.menus ? renderWithParentWithMenus(values, i, useReactRouterLinks) : renderWithParentWithoutMenus(values, i, useReactRouterLinks)
          )
        ]
      })
    ] })
  );
};
var renderWithoutParent = (allChildren, useReactRouterLinks) => {
  return allChildren.map(
    (values, i) => values.menus ? /* @__PURE__ */ (0, import_jsx_runtime32.jsx)("li", { className: `menu-item-has-children`, children: childParametersForward(values.link, values.heading, useReactRouterLinks) }, i) : /* @__PURE__ */ (0, import_jsx_runtime32.jsx)("li", { className: ``, children: itemMenuWithoutChildren(values.link, values.heading, useReactRouterLinks) }, i)
  );
};

// src/components/navigations/mainMenu.tsx
var import_jsx_runtime33 = require("react/jsx-runtime");
function MainMenu({
  mainMenuStructure,
  useReactRouterLinks
}) {
  const [ancestorOrParentClass, setAncestorOrParentClass] = (0, import_react13.useState)("current-menu-parent");
  const [navContainerMenu, setNavContainerMenu] = (0, import_react13.useState)("current-menu-ancestor");
  const [changeMenu, setChangeMenu] = (0, import_react13.useState)();
  function clickHandler(event) {
    event.preventDefault();
    const forward = event.target.offsetParent.className.includes("forward");
    const backwardsClassName = event.target.className.includes("icon") || event.target.className.includes("icon-container") ? event.target.offsetParent.id : event.target.className;
    const labelClassName = event.target.textContent ? event.target.textContent : event.target.offsetParent.id;
    const foundMenuDisplay = findMenuDisplay(forward, backwardsClassName, labelClassName, mainMenuStructure, void 0, void 0);
    if (backwardsClassName === "back") {
      setChangeMenu(foundMenuDisplay);
      if (foundMenuDisplay.parent == void 0) {
        setNavContainerMenu("current-menu-parent");
        setAncestorOrParentClass("");
      }
    } else if (forward) {
      setChangeMenu(foundMenuDisplay);
      if (foundMenuDisplay.parent != void 0) {
        setNavContainerMenu("current-menu-ancestor");
        setAncestorOrParentClass("current-menu-parent");
      }
    }
  }
  const found = changeMenu ? changeMenu : findCurrentItem(mainMenuStructure, void 0, void 0);
  const allChildren = found ? found.items.map(({ heading, link, currentItem, menus }) => ({ heading, link, currentItem, menus })) : (mainMenuStructure || []).map((values) => values);
  const parent = found ? found.parent : "";
  (0, import_react13.useEffect)(() => {
    if (!found) {
      setNavContainerMenu("current-menu-parent");
      setAncestorOrParentClass("");
    }
  }, []);
  const getMainMenu = () => {
    return /* @__PURE__ */ (0, import_jsx_runtime33.jsx)(import_jsx_runtime33.Fragment, { children: /* @__PURE__ */ (0, import_jsx_runtime33.jsxs)("div", { className: "nav-solid-layout", children: [
      /* @__PURE__ */ (0, import_jsx_runtime33.jsx)("div", { className: "overlay" }),
      /* @__PURE__ */ (0, import_jsx_runtime33.jsx)("nav", { className: "nav-main", id: "main-navigation", role: "navigation", children: /* @__PURE__ */ (0, import_jsx_runtime33.jsx)("div", { className: "nav-wrapper", children: /* @__PURE__ */ (0, import_jsx_runtime33.jsx)("div", { className: `nav-container ${navContainerMenu}`, onClick: clickHandler, children: /* @__PURE__ */ (0, import_jsx_runtime33.jsx)("ul", {
        className: "nav-menu",
        //Condition to display the menu with parent or without parent if parent exist
        children: parent ? renderWithParent(parent, ancestorOrParentClass, allChildren, useReactRouterLinks) : renderWithoutParent(allChildren, useReactRouterLinks)
      }) }) }) })
    ] }) });
  };
  return /* @__PURE__ */ (0, import_jsx_runtime33.jsx)(import_jsx_runtime33.Fragment, { children: getMainMenu() });
}

// src/components/navigations/topmenu.tsx
var import_elements_min16 = require("epfl-elements/dist/css/elements.min.css");
var import_jsx_runtime34 = require("react/jsx-runtime");
var getMenuItem = (item, i) => /* @__PURE__ */ (0, import_jsx_runtime34.jsx)(
  "li",
  {
    id: `menu-item--${i}`,
    className: item.active ? "current-menu-item" : "",
    children: /* @__PURE__ */ (0, import_jsx_runtime34.jsx)("a", { className: "nav-item", href: item.link, children: item.anchor }, `a-${i}`)
  },
  `li-${i}`
);
function Topmenu({ menuItems }) {
  return /* @__PURE__ */ (0, import_jsx_runtime34.jsx)("ul", { id: "top-menu", className: "nav-header d-none d-xl-flex", children: menuItems && Array.isArray(menuItems) && menuItems.map((item, x) => item && getMenuItem(item, x)) });
}

// src/components/Footer/common.tsx
var import_jsx_runtime35 = require("react/jsx-runtime");
var getCurrentYear = () => (/* @__PURE__ */ new Date()).getFullYear();
var getLegal = () => /* @__PURE__ */ (0, import_jsx_runtime35.jsxs)("div", { className: "footer-legal", children: [
  /* @__PURE__ */ (0, import_jsx_runtime35.jsxs)("div", { className: "footer-legal-links", children: [
    /* @__PURE__ */ (0, import_jsx_runtime35.jsx)("a", { href: "https://www.epfl.ch/about/overview/regulations-and-guidelines/disclaimer/", children: "Accessibility" }),
    /* @__PURE__ */ (0, import_jsx_runtime35.jsx)("a", { href: "https://www.epfl.ch/about/overview/regulations-and-guidelines/disclaimer/", children: "Disclaimer" }),
    /* @__PURE__ */ (0, import_jsx_runtime35.jsx)("a", { href: "https://go.epfl.ch/privacy-policy/", children: "Privacy policy" })
  ] }),
  /* @__PURE__ */ (0, import_jsx_runtime35.jsx)("div", { children: /* @__PURE__ */ (0, import_jsx_runtime35.jsxs)("p", { children: [
    "\xA9 ",
    getCurrentYear(),
    " EPFL, all rights reserved"
  ] }) })
] });
var getBackToTop = () => /* @__PURE__ */ (0, import_jsx_runtime35.jsxs)("button", { id: "back-to-top", className: "btn btn-primary btn-back-to-top", children: [
  /* @__PURE__ */ (0, import_jsx_runtime35.jsx)("span", { className: "sr-only", children: "Back to top" }),
  /* @__PURE__ */ (0, import_jsx_runtime35.jsx)("svg", { className: "icon", "aria-hidden": "true", children: /* @__PURE__ */ (0, import_jsx_runtime35.jsx)("use", { xlinkHref: "#icon-chevron-top" }) })
] });

// src/components/Footer/footersocialcontents.json
var socials = [
  {
    name: "Facebook",
    link: "https://www.facebook.com/epflcampus",
    anchor: "Follow us on Facebook.",
    iconclass: "icon-facebook"
  },
  {
    name: "Twitter",
    link: "https://twitter.com/epfl'",
    anchor: "Follow us on Twitter.",
    iconclass: "icon-twitter"
  },
  {
    name: "Instagram",
    link: "https://instagram.com/epflcampus",
    anchor: "Follow us on Instagram.",
    iconclass: "icon-instagram"
  },
  {
    name: "Youtube",
    link: "https://www.youtube.com/user/epflnews",
    anchor: "Follow us on Youtube.",
    iconclass: "icon-youtube"
  },
  {
    name: "LinkedIn",
    link: "https://www.youtube.com/user/epflnews",
    anchor: "Follow us on LinkedIn.",
    iconclass: "icon-linkedin"
  }
];

// src/components/Footer/elementsConfigData.json
var schools = [
  {
    name_fr: "Facult\xE9 de l'environnement naturel, architectural et construit",
    name_en: "School of Architecture, Civil and Environmental Engineering",
    name_de: "Fakult\xE4t f\xFCr Bau, Architektur und Umwelt",
    acronym: "ENAC",
    url_fr: "https://www.epfl.ch/schools/enac/fr/",
    url_en: "https://www.epfl.ch/schools/enac/",
    url_de: "https://www.epfl.ch/schools/enac/"
  },
  {
    name_fr: "Facult\xE9 des sciences de base",
    name_en: "School of Basic Sciences",
    name_de: "Fakult\xE4t f\xFCr Grundlagenwissenschaften",
    acronym: "SB",
    url_fr: "https://www.epfl.ch/schools/sb/fr/",
    url_en: "https://www.epfl.ch/schools/sb/",
    url_de: "https://www.epfl.ch/schools/sb/"
  },
  {
    name_fr: "Facult\xE9 des sciences et techniques de l'ing\xE9nieur",
    name_en: "School of Engineering",
    name_de: "Fakult\xE4t f\xFCr Ingenieurwissenschaften",
    acronym: "STI",
    url_fr: "https://sti.epfl.ch/fr/",
    url_en: "https://sti.epfl.ch",
    url_de: "https://sti.epfl.ch"
  },
  {
    name_fr: "Facult\xE9 informatique et communications",
    name_en: "School of Computer and Communication Sciences",
    name_de: "Fakult\xE4t f\xFCr Informatik und Kommunikation",
    acronym: "IC",
    url_fr: "https://www.epfl.ch/schools/ic/fr/",
    url_en: "https://www.epfl.ch/schools/ic/",
    url_de: "https://www.epfl.ch/schools/ic/"
  },
  {
    name_fr: "Facult\xE9 des sciences de la vie",
    name_en: "School of Life Sciences",
    name_de: "Fakult\xE4t f\xFCr Lebenswissenschaften",
    acronym: "SV",
    url_fr: "https://www.epfl.ch/schools/sv/fr/",
    url_en: "https://www.epfl.ch/schools/sv/",
    url_de: "https://www.epfl.ch/schools/sv/"
  },
  {
    name_fr: "Coll\xE8ge du management de la technologie",
    name_en: "College of Management of Technology",
    name_de: "College of Management of Technology",
    acronym: "CDM",
    url_fr: "https://www.epfl.ch/schools/cdm/fr/",
    url_en: "https://www.epfl.ch/schools/cdm/",
    url_de: "https://www.epfl.ch/schools/cdm/"
  },
  {
    name_fr: "Coll\xE8ge des humanit\xE9s",
    name_en: "College of Humanities",
    name_de: "College of Humanities CDH",
    acronym: "CDH",
    url_fr: "https://www.epfl.ch/schools/cdh/fr/",
    url_en: "https://www.epfl.ch/schools/cdh/",
    url_de: "https://www.epfl.ch/schools/cdh/"
  },
  {
    name_fr: "Middle East",
    name_en: "Middle East",
    name_de: "Middle East",
    acronym: "ME",
    url_fr: "http://www.epfl.ae",
    target_blank_fr: true,
    rel_noopener_fr: true,
    url_en: "http://www.epfl.ae",
    target_blank_en: true,
    rel_noopener_en: true,
    url_de: "http://www.epfl.ae",
    target_blank_de: true,
    rel_noopener_de: true
  }
];
var footer = [
  {
    heading_fr: "\xC0 propos",
    heading_en: "About",
    heading_de: "\xDCber uns",
    items: [
      {
        name_fr: "Pr\xE9sentation",
        url_fr: "https://www.epfl.ch/about/overview/fr/",
        name_en: "Presentation",
        url_en: "https://www.epfl.ch/about/overview/",
        name_de: "Pr\xE4sentation",
        url_de: "https://www.epfl.ch/about/overview/de/"
      },
      {
        name_fr: "Pr\xE9sidence",
        url_fr: "https://www.epfl.ch/about/presidency/fr/",
        name_en: "Presidency",
        url_en: "https://www.epfl.ch/about/presidency/",
        name_de: "Pr\xE4sidium",
        url_de: "https://www.epfl.ch/about/presidency/de/"
      },
      {
        name_fr: "Vice-Pr\xE9sidences",
        url_fr: "https://www.epfl.ch/about/vice-presidencies/fr/",
        name_en: "Vice-presidencies",
        url_en: "https://www.epfl.ch/about/vice-presidencies/",
        name_de: "Vizepr\xE4sidium",
        url_de: "https://www.epfl.ch/about/vice-presidencies/de/"
      },
      {
        name_fr: "Campus associ\xE9s",
        url_fr: "https://www.epfl.ch/about/campus/fr/",
        name_en: "Associated campuses",
        url_en: "https://www.epfl.ch/about/campus/",
        name_de: "Assoziierte Campus",
        url_de: "https://www.epfl.ch/about/campus/de/"
      },
      {
        name_fr: "Travailler \xE0 l'EPFL",
        url_fr: "https://www.epfl.ch/about/working/fr/",
        name_en: "Working at EPFL",
        url_en: "https://www.epfl.ch/about/working/",
        name_de: "Bei der EPFL arbeiten",
        url_de: "https://www.epfl.ch/about/working/"
      },
      {
        name_fr: "Recruter des talents de l'EPFL",
        url_fr: "https://www.epfl.ch/about/recruiting/fr/",
        name_en: "Recruiting EPFL talents",
        url_en: "https://www.epfl.ch/about/recruiting/",
        name_de: "EPFL Talente",
        url_de: "https://www.epfl.ch/about/recruiting/"
      },
      {
        name_fr: "News & m\xE9dias",
        url_fr: "https://www.epfl.ch/about/news-and-media/fr/",
        name_en: "News & media",
        url_en: "https://www.epfl.ch/about/news-and-media/",
        name_de: "News & Medien",
        url_de: "https://www.epfl.ch/about/news-and-media/de/"
      },
      {
        name_fr: "Durabilit\xE9",
        url_fr: "https://www.epfl.ch/about/sustainability/fr/",
        name_en: "Sustainability",
        url_en: "https://www.epfl.ch/about/sustainability/",
        name_de: "Nachhaltigkeit",
        url_de: "https://www.epfl.ch/about/sustainability/"
      },
      {
        name_fr: "\xC9galit\xE9 des chances",
        url_fr: "https://www.epfl.ch/about/equality/fr/",
        name_en: "Equality",
        url_en: "https://www.epfl.ch/about/equality/",
        name_de: "Chancengleichheit",
        url_de: "https://www.epfl.ch/about/equality/"
      },
      {
        name_fr: "Philanthropie",
        url_fr: "https://www.epfl.ch/about/philanthropy/fr/",
        name_en: "Philanthropy",
        url_en: "https://www.epfl.ch/about/philanthropy/",
        name_de: "Philanthropie\n",
        url_de: "https://www.epfl.ch/about/philanthropy/"
      },
      {
        name_fr: "Cooperation",
        url_fr: "https://essentialtech.center",
        target_blank_fr: true,
        rel_noopener_fr: true,
        name_en: "Cooperation",
        url_en: "https://essentialtech.center",
        target_blank_en: true,
        rel_noopener_en: true,
        name_de: "Zusammenarbeit",
        url_de: "https://essentialtech.center",
        target_blank_de: true,
        rel_noopener_de: true
      },
      {
        name_fr: "Alumni",
        url_fr: "https://www.epflalumni.ch/fr/",
        name_en: "Alumni",
        target_blank_fr: true,
        rel_noopener_fr: true,
        url_en: "https://www.epflalumni.ch",
        target_blank_en: true,
        rel_noopener_en: true,
        name_de: "Alumni",
        url_de: "https://www.epflalumni.ch",
        target_blank_de: true,
        rel_noopener_de: true
      }
    ]
  },
  {
    heading_fr: "\xC9ducation",
    heading_en: "Education",
    heading_de: "Bildung",
    items: [
      {
        name_fr: "Bachelor",
        url_fr: "https://www.epfl.ch/education/bachelor/fr/",
        name_en: "Bachelor",
        url_en: "https://www.epfl.ch/education/bachelor/",
        name_de: "Bachelor",
        url_de: "https://www.epfl.ch/education/bachelor/de/"
      },
      {
        name_fr: "Master",
        url_fr: "https://www.epfl.ch/education/master/fr/",
        name_en: "Master",
        url_en: "https://www.epfl.ch/education/master/",
        name_de: "Master",
        url_de: "https://www.epfl.ch/education/master/de/"
      },
      {
        name_fr: "Doctorat",
        url_fr: "https://www.epfl.ch/education/phd/fr/",
        name_en: "Doctorate",
        url_en: "https://www.epfl.ch/education/phd/",
        name_de: "Doktorat",
        url_de: "https://www.epfl.ch/education/phd/de/"
      },
      {
        name_fr: "Formation continue",
        url_fr: "https://www.epfl.ch/education/continuing-education/fr/",
        name_en: "Continuing education",
        url_en: "https://www.epfl.ch/education/continuing-education/",
        name_de: "Weiterbildung",
        url_de: "https://www.epfl.ch/education/continuing-education/"
      },
      {
        name_fr: "International",
        url_fr: "https://www.epfl.ch/education/international/fr/",
        name_en: "International",
        url_en: "https://www.epfl.ch/education/international/en/",
        name_de: "International",
        url_de: "https://www.epfl.ch/education/international/de/"
      },
      {
        name_fr: "Admission",
        url_fr: "https://www.epfl.ch/education/admission/fr/",
        name_en: "Admission",
        url_en: "https://www.epfl.ch/education/admission/",
        name_de: "Zulassung",
        url_de: "https://www.epfl.ch/education/admission/de/"
      },
      {
        name_fr: "Gestion des \xE9tudes",
        url_fr: "https://www.epfl.ch/education/studies/",
        name_en: "Study management",
        url_en: "https://www.epfl.ch/education/studies/en/",
        name_de: "Studienverwaltung",
        url_de: "https://www.epfl.ch/education/studies/de/"
      },
      {
        name_fr: "Initiatives p\xE9dagogiques",
        url_fr: "https://www.epfl.ch/education/educational-initiatives/fr/",
        name_en: "Educational initiatives",
        url_en: "https://www.epfl.ch/education/educational-initiatives/",
        name_de: "Bildungsinitiativen",
        url_de: "https://www.epfl.ch/education/educational-initiatives/de/"
      },
      {
        name_fr: "Promotion de l'\xE9ducation et des sciences",
        url_fr: "https://www.epfl.ch/education/education-and-science-outreach/fr/",
        name_en: "Sciences and education outreach",
        url_en: "https://www.epfl.ch/education/education-and-science-outreach/",
        name_de: "F\xF6rderung von Bildung und Wissenschaft",
        url_de: "https://www.epfl.ch/education/education-and-science-outreach/de/"
      }
    ]
  },
  {
    heading_fr: "Recherche",
    heading_en: "Research",
    heading_de: "Forschung",
    items: [
      {
        name_fr: "Domaines de recherche",
        url_fr: "https://www.epfl.ch/research/domains/fr/",
        name_en: "Research domains",
        url_en: "https://www.epfl.ch/research/domains/",
        name_de: "Forschungsbereiche",
        url_de: "https://www.epfl.ch/research/domains/de/"
      },
      {
        name_fr: "Nos Professeurs",
        url_fr: "https://www.epfl.ch/research/faculty-members/fr/",
        name_en: "Faculty members",
        url_en: "https://www.epfl.ch/research/faculty-members/",
        name_de: "Unsere Lehrkr\xE4fte",
        url_de: "https://www.epfl.ch/research/faculty-members/de/"
      },
      {
        name_fr: "Collaborer avec nos chercheurs",
        url_fr: "https://www.epfl.ch/research/collaborate/fr/",
        name_en: "Collaborate with our researchers",
        url_en: "https://www.epfl.ch/research/collaborate/",
        name_de: "Mit unseren Forschenden zusammenarbeiten",
        url_de: "https://www.epfl.ch/research/collaborate/de/"
      },
      {
        name_fr: "Utiliser nos infrastructures",
        url_fr: "https://www.epfl.ch/research/facilities/fr/",
        name_en: "Use our infrastructure",
        url_en: "https://www.epfl.ch/research/facilities/",
        name_de: "Unsere Infrastruktur nutzen",
        url_de: "https://www.epfl.ch/research/facilities/de/"
      },
      {
        name_fr: "Acc\xE9der \xE0 nos technologies",
        url_fr: "https://www.epfl.ch/research/access-technology/fr/",
        name_en: "Access our technologies",
        url_en: "https://www.epfl.ch/research/access-technology/",
        name_de: "Auf unsere Technologien zugreifen",
        url_de: "https://www.epfl.ch/research/access-technology/de/"
      },
      {
        name_fr: "Services pour nos laboratoires",
        url_fr: "https://www.epfl.ch/research/services/fr/",
        name_en: "Services to laboratories",
        url_en: "https://www.epfl.ch/research/services/",
        name_de: "Dienste f\xFCr EPFL-Labore",
        url_de: "https://www.epfl.ch/research/services/de/"
      },
      {
        name_fr: "D\xE9ontologie et \xE9thique",
        url_fr: "https://www.epfl.ch/research/ethic-statement/fr/",
        name_en: "Research ethics",
        url_en: "https://www.epfl.ch/research/ethic-statement/",
        name_de: "Forschungsethik",
        url_de: "https://www.epfl.ch/research/ethic-statement/de/"
      },
      {
        name_fr: "Prix et distinctions",
        url_fr: "https://www.epfl.ch/research/awards/fr/",
        name_en: "Awards and prizes",
        url_en: "https://www.epfl.ch/research/awards/",
        name_de: "Preise und Auszeichnungen",
        url_de: "https://www.epfl.ch/research/awards/de/"
      },
      {
        name_fr: "Open Science",
        url_fr: "https://www.epfl.ch/research/open-science/fr/",
        name_en: "Open Science",
        url_en: "https://www.epfl.ch/research/open-science/",
        name_de: "Open Science",
        url_de: "https://www.epfl.ch/research/open-science/de/"
      }
    ]
  },
  {
    heading_fr: "Innovation",
    heading_en: "Innovation",
    heading_de: "Innovation",
    items: [
      {
        name_fr: "Domaines d'innovation",
        url_fr: "https://www.epfl.ch/innovation/domains/fr/",
        name_en: "Domains of innovation",
        url_en: "https://www.epfl.ch/innovation/domains/",
        name_de: "Innovationsbereiche",
        url_de: "https://www.epfl.ch/innovation/domains/de/"
      },
      {
        name_fr: "Collaboration avec l'industrie",
        url_fr: "https://www.epfl.ch/innovation/industry/fr/",
        name_en: "Industry collaborations",
        url_en: "https://www.epfl.ch/innovation/industry/",
        name_de: "Zusammenarbeit mit der Industrie",
        url_de: "https://www.epfl.ch/innovation/industry/de/"
      },
      {
        name_fr: "Unit\xE9 Start-up",
        url_fr: "https://www.epfl.ch/innovation/startup/fr/",
        name_en: "Startup launchpad",
        url_en: "https://www.epfl.ch/innovation/startup/",
        name_de: "Unternehmertum und Start-ups",
        url_de: "https://www.epfl.ch/innovation/startup/de/"
      }
    ]
  },
  {
    heading_fr: "Campus",
    heading_en: "Campus",
    heading_de: "Campus",
    items: [
      {
        name_fr: "Visiter l'EPFL",
        url_fr: "https://www.epfl.ch/campus/visitors/fr/",
        name_en: "Visit EPFL",
        url_en: "https://www.epfl.ch/campus/visitors/",
        name_de: "EPFL Besuchen",
        url_de: "https://www.epfl.ch/campus/visitors/de/"
      },
      {
        name_fr: "Services et ressources",
        url_fr: "https://www.epfl.ch/campus/services/",
        name_en: "Services and resources",
        url_en: "https://www.epfl.ch/campus/services/en/",
        name_de: "Services und Ressourcen",
        url_de: "https://www.epfl.ch/campus/services/en/"
      },
      {
        name_fr: "Biblioth\xE8que",
        url_fr: "https://www.epfl.ch/campus/library/fr/",
        name_en: "Library",
        url_en: "https://www.epfl.ch/campus/library/",
        name_de: "Bibliothek",
        url_de: "https://www.epfl.ch/campus/library/"
      },
      {
        name_fr: "Restaurants, shops et h\xF4tels",
        url_fr: "https://www.epfl.ch/campus/restaurants-shops-hotels/fr/",
        name_en: "Restaurants, shops and hotels",
        url_en: "https://www.epfl.ch/campus/restaurants-shops-hotels/",
        name_de: "Restaurants, Gesch\xE4fte und Hotels",
        url_de: "https://www.epfl.ch/campus/restaurants-shops-hotels/"
      },
      {
        name_fr: "\xC9v\xE9nements",
        url_fr: "https://www.epfl.ch/campus/events/fr/",
        name_en: "Events",
        url_en: "https://www.epfl.ch/campus/events/",
        name_de: "Veranstaltungen",
        url_de: "https://www.epfl.ch/campus/events/"
      },
      {
        name_fr: "Sport",
        url_fr: "https://www.epfl.ch/campus/sports/",
        name_en: "Sports",
        url_en: "https://www.epfl.ch/campus/sports/en/",
        name_de: "Sport",
        url_de: "https://www.epfl.ch/campus/sports/en/"
      },
      {
        name_fr: "Arts et culture",
        url_fr: "https://www.epfl.ch/campus/art-culture/fr/",
        name_en: "Arts and culture",
        url_en: "https://www.epfl.ch/campus/art-culture/",
        name_de: "Kunst und Kultur",
        url_de: "https://www.epfl.ch/campus/art-culture/"
      },
      {
        name_fr: "Aide, sant\xE9 et s\xE9curit\xE9",
        url_fr: "https://www.epfl.ch/campus/security-safety/",
        name_en: "Health, security and safety",
        url_en: "https://www.epfl.ch/campus/security-safety/en/",
        name_de: "Hilfe, Gesundheit und Sicherheit",
        url_de: "https://www.epfl.ch/campus/security-safety/en/"
      },
      {
        name_fr: "Aum\xF4nerie",
        url_fr: "https://www.epfl.ch/campus/spiritual-care/",
        name_en: "Chaplaincy",
        url_en: "https://www.epfl.ch/campus/spiritual-care/en/",
        name_de: "Seelsorge",
        url_de: "https://www.epfl.ch/campus/spiritual-care/en/"
      },
      {
        name_fr: "Associations",
        url_fr: "https://www.epfl.ch/campus/associations/fr/",
        name_en: "Associations",
        url_en: "https://www.epfl.ch/campus/associations/",
        name_de: "Vereinigungen",
        url_de: "https://www.epfl.ch/campus/associations/"
      },
      {
        name_fr: "Mobilit\xE9 et transport",
        url_fr: "https://www.epfl.ch/campus/mobility/fr/",
        name_en: "Mobility and transport",
        url_en: "https://www.epfl.ch/campus/mobility/",
        name_de: "Mobilit\xE4t und Transport",
        url_de: "https://www.epfl.ch/campus/mobility/"
      }
    ]
  }
];

// src/components/Footer/Footer.tsx
var import_jsx_runtime36 = require("react/jsx-runtime");
var getId = (section, i, element) => `${element}_${i}_${section}`;
var getSiteMap = (sitemap) => /* @__PURE__ */ (0, import_jsx_runtime36.jsx)("div", { className: "footer-group footer-sitemap", children: sitemap.map(
  (section, i) => /* @__PURE__ */ (0, import_jsx_runtime36.jsxs)("div", { className: "footer-sitemap-col", children: [
    /* @__PURE__ */ (0, import_jsx_runtime36.jsx)(
      "button",
      {
        className: "footer-title collapse-title collapsed",
        type: "button",
        "data-toggle": "collapse",
        "data-target": `#collapse-footer-${i}`,
        "aria-expanded": "false",
        "aria-controls": `#collapse-footer-${i}`,
        children: /* @__PURE__ */ (0, import_jsx_runtime36.jsx)("strong", { children: section.heading_en })
      }
    ),
    /* @__PURE__ */ (0, import_jsx_runtime36.jsx)("div", { className: "collapse collapse-item", id: `collapse-footer-${i}`, children: /* @__PURE__ */ (0, import_jsx_runtime36.jsx)("ul", { className: "footer-links", children: section.items.map(
      (item, i2) => /* @__PURE__ */ (0, import_jsx_runtime36.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime36.jsx)("a", { href: item.url_en, children: item.name_en }) }, getId(section.heading_en, i2, "li"))
    ) }) })
  ] }, getId(section, i, "div"))
) });
var getSchools = (schools2) => /* @__PURE__ */ (0, import_jsx_runtime36.jsx)("div", { className: "footer-group", children: /* @__PURE__ */ (0, import_jsx_runtime36.jsxs)("div", { className: "footer-faculties", children: [
  /* @__PURE__ */ (0, import_jsx_runtime36.jsx)(
    "button",
    {
      className: "footer-title collapse-title collapsed",
      type: "button",
      "data-toggle": "collapse",
      "data-target": "#collapse-fac",
      "aria-expanded": "false",
      "aria-controls": "collapse-fac",
      children: "Schools"
    }
  ),
  /* @__PURE__ */ (0, import_jsx_runtime36.jsx)("div", { className: "collapse collapse-item", id: "collapse-fac", children: /* @__PURE__ */ (0, import_jsx_runtime36.jsx)("ul", { className: "footer-links", children: schools2.map((s, i) => /* @__PURE__ */ (0, import_jsx_runtime36.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime36.jsxs)("a", { href: s.url_en, children: [
    s.name_en,
    " ",
    /* @__PURE__ */ (0, import_jsx_runtime36.jsx)("strong", { children: s.acronym })
  ] }) }, i)) }) })
] }) });
var getServicesInfo = () => /* @__PURE__ */ (0, import_jsx_runtime36.jsxs)("div", { className: "footer-group footer-buttons", children: [
  /* @__PURE__ */ (0, import_jsx_runtime36.jsx)("p", { className: "footer-title footer-title-no-underline", children: "Practical" }),
  /* @__PURE__ */ (0, import_jsx_runtime36.jsx)("a", { href: "https://www.epfl.ch/campus/services/en/homepage/", className: "btn btn-secondary btn-sm", children: "Services and resources" }),
  /* @__PURE__ */ (0, import_jsx_runtime36.jsx)("a", { href: "tel:+41216933000", className: "btn btn-secondary btn-sm", children: "Emergencies: +41 21 693 3000" }),
  /* @__PURE__ */ (0, import_jsx_runtime36.jsx)("a", { href: "https://www.epfl.ch/about/overview/contact-en/", className: "btn btn-secondary btn-sm", children: "Contact" }),
  /* @__PURE__ */ (0, import_jsx_runtime36.jsx)("a", { href: "https://map.epfl.ch/", className: "btn btn-secondary btn-sm", children: "Map" })
] });
var getSocial = () => /* @__PURE__ */ (0, import_jsx_runtime36.jsxs)("div", { className: "footer-group footer-socials", children: [
  /* @__PURE__ */ (0, import_jsx_runtime36.jsx)("p", { className: "footer-title footer-title-no-underline", children: "Follow EPFL on social media" }),
  /* @__PURE__ */ (0, import_jsx_runtime36.jsx)("div", { className: "footer-social", children: socials.map((item, i) => /* @__PURE__ */ (0, import_jsx_runtime36.jsxs)("a", { href: item.link, className: `social-icon social-${item.iconclass} social-icon-negative`, target: "_blank", rel: "nofollow noopener", children: [
    /* @__PURE__ */ (0, import_jsx_runtime36.jsx)("svg", { className: "icon", "aria-hidden": "true", children: /* @__PURE__ */ (0, import_jsx_runtime36.jsx)("use", { xlinkHref: `#${item.iconclass}` }) }),
    /* @__PURE__ */ (0, import_jsx_runtime36.jsx)("span", { className: "sr-only", children: item.anchor })
  ] }, i)) })
] });
function Footer({ sitemap = footer, schools: schools2 = schools }) {
  return /* @__PURE__ */ (0, import_jsx_runtime36.jsx)("div", { className: "bg-gray-100 py-5 mt-5", children: /* @__PURE__ */ (0, import_jsx_runtime36.jsxs)("div", { className: "container", children: [
    /* @__PURE__ */ (0, import_jsx_runtime36.jsxs)("footer", { className: "footer", role: "contentinfo", children: [
      sitemap.length > 0 && getSiteMap(sitemap),
      schools2.length > 0 && getSchools(schools2),
      getServicesInfo(),
      getSocial(),
      getLegal()
    ] }),
    getBackToTop()
  ] }) });
}

// src/components/Footer/FooterLight.tsx
var import_jsx_runtime37 = require("react/jsx-runtime");
var getSocialLight = () => /* @__PURE__ */ (0, import_jsx_runtime37.jsxs)("p", { className: "footer-light-socials", children: [
  /* @__PURE__ */ (0, import_jsx_runtime37.jsx)("small", { children: "Follow EPFL on social media" }),
  socials.map((item, i) => /* @__PURE__ */ (0, import_jsx_runtime37.jsxs)("a", { href: item.link, className: `social-icon social-${item.iconclass} social-icon-negative`, target: "_blank", rel: "nofollow noopener", children: [
    /* @__PURE__ */ (0, import_jsx_runtime37.jsx)("svg", { className: "icon", "aria-hidden": "true", children: /* @__PURE__ */ (0, import_jsx_runtime37.jsx)("use", { xlinkHref: `#${item.iconclass}` }) }),
    /* @__PURE__ */ (0, import_jsx_runtime37.jsx)("span", { className: "sr-only", children: item.anchor })
  ] }, i))
] });
function FooterLight() {
  return /* @__PURE__ */ (0, import_jsx_runtime37.jsx)("div", { className: "bg-gray-100 pt-5", children: /* @__PURE__ */ (0, import_jsx_runtime37.jsxs)("div", { className: "container", children: [
    /* @__PURE__ */ (0, import_jsx_runtime37.jsx)("footer", { className: "footer-light", role: "contentinfo", children: /* @__PURE__ */ (0, import_jsx_runtime37.jsxs)("div", { className: "row", children: [
      /* @__PURE__ */ (0, import_jsx_runtime37.jsx)("div", { className: "col-6 mx-auto mx-md-0 mb-4 col-md-3 col-lg-2", children: /* @__PURE__ */ (0, import_jsx_runtime37.jsx)(Logo, {}) }),
      /* @__PURE__ */ (0, import_jsx_runtime37.jsx)("div", { className: "col-md-9 col-lg-10 mb-4", children: /* @__PURE__ */ (0, import_jsx_runtime37.jsxs)("div", { className: "ml-md-2 ml-lg-5", children: [
        /* @__PURE__ */ (0, import_jsx_runtime37.jsxs)("ul", { className: "list-inline list-unstyled", children: [
          /* @__PURE__ */ (0, import_jsx_runtime37.jsx)("li", { className: "list-inline-item", children: "Contact" }),
          /* @__PURE__ */ (0, import_jsx_runtime37.jsx)("li", { className: "list-inline-item text-muted pl-3", children: /* @__PURE__ */ (0, import_jsx_runtime37.jsx)("small", { children: "EPFL CH-1015 Lausanne" }) }),
          /* @__PURE__ */ (0, import_jsx_runtime37.jsx)("li", { className: "list-inline-item text-muted pl-3", children: /* @__PURE__ */ (0, import_jsx_runtime37.jsx)("small", { children: "+41 21 693 11 11" }) })
        ] }),
        getSocialLight(),
        getLegal()
      ] }) })
    ] }) }),
    getBackToTop()
  ] }) });
}

// src/components/Header/index.tsx
var import_elements_min17 = require("epfl-elements/dist/css/elements.min.css");
var import_jsx_runtime38 = require("react/jsx-runtime");
function Header({ topMenuItems, drawerContents, user, logOutUrl, avatarLogoUrl, avatarLogoAltText }) {
  const getAvatar = () => /* @__PURE__ */ (0, import_jsx_runtime38.jsx)(Avatar, { user, logOutUrl, logoUrl: avatarLogoUrl, logoAltText: avatarLogoAltText });
  return /* @__PURE__ */ (0, import_jsx_runtime38.jsxs)("header", { role: "banner", className: "header", children: [
    drawerContents && /* @__PURE__ */ (0, import_jsx_runtime38.jsx)(Drawer, { contents: drawerContents }),
    /* @__PURE__ */ (0, import_jsx_runtime38.jsx)(Logo, {}),
    /* @__PURE__ */ (0, import_jsx_runtime38.jsx)(Topmenu, { menuItems: topMenuItems }),
    user && getAvatar()
  ] });
}

// src/components/Tabset/index.tsx
var import_react14 = require("react");
var import_elements_min18 = require("epfl-elements/dist/css/elements.min.css");
var import_jsx_runtime39 = require("react/jsx-runtime");
function Tabset({ tabs }) {
  const getTabsIds = (tabsObj) => Object.keys(tabsObj);
  const [activeTab, setActiveTab] = (0, import_react14.useState)(tabs[getTabsIds(tabs).filter(
    (tabid) => tabs[tabid].isActive
  )[0]].id);
  async function clickHandler(tab) {
    if (activeTab === tab.id) {
      return;
    }
    if (!tab.disableSwitch) {
      setActiveTab(tab.id);
    }
    if (tab.clickFn) {
      await tab.clickFn();
    }
  }
  function getHeaderClass(tab) {
    const baseClass = "nav-link";
    if (tab.id === activeTab) {
      return `${baseClass} active`;
    } else if (tab.disabled) {
      return `${baseClass} disabled`;
    }
    return baseClass;
  }
  const getTabHeader = (tab) => /* @__PURE__ */ (0, import_jsx_runtime39.jsx)("li", { className: "nav-item", children: /* @__PURE__ */ (0, import_jsx_runtime39.jsx)(
    "a",
    {
      className: getHeaderClass(tab),
      id: `${tab.id}-tab`,
      "data-toggle": "tab",
      onClick: () => clickHandler(tab),
      children: tab.label
    },
    `${tab.id}-tab`
  ) }, `${tab.id}-tab-li`);
  const getTabContent = (tab) => /* @__PURE__ */ (0, import_jsx_runtime39.jsx)(
    "div",
    {
      className: tab.id === activeTab ? "tab-pane fade show active" : "tab-pane fade",
      id: `${tab.id}`,
      role: "tabpanel",
      children: tab.renderContent && tab.renderContent()
    },
    `${tab.id}-div`
  );
  return /* @__PURE__ */ (0, import_jsx_runtime39.jsxs)("div", { className: "container-full", children: [
    /* @__PURE__ */ (0, import_jsx_runtime39.jsx)("ul", { className: "nav nav-tabs", role: "tablist", children: getTabsIds(tabs).map((id) => getTabHeader(tabs[id])) }),
    /* @__PURE__ */ (0, import_jsx_runtime39.jsx)("div", { className: `tab-content p-${getTabsIds(tabs).length}`, children: getTabsIds(tabs).map((id) => getTabContent(tabs[id])) })
  ] });
}

// src/components/Tabset/helpers.ts
function tabUpdateContents({ tab, tabContents, setTabFn }) {
  setTabFn({
    ...tab,
    renderContent: () => tabContents
  });
}

// src/components/utils/setPageTitle.tsx
var import_react15 = require("react");
function SetPageTitle(baseTitle, title) {
  const capitalize = (str) => (str || "").replace(/\b\w/g, (l) => l.toUpperCase());
  function getTitle() {
    if (title) {
      return `${baseTitle} - ${title}`;
    }
    try {
      if (document.location.pathname === "/") {
        return `${baseTitle} - About`;
      }
      const parts = document.location.pathname.split("/").filter((x) => x);
      return `${baseTitle} - ${capitalize(parts[0])} - ${capitalize(parts.slice(-1)[0])}`;
    } catch (err) {
      console.error("Could not generate the title return default");
      return baseTitle;
    }
  }
  (0, import_react15.useEffect)(() => {
    document.location && baseTitle && (document.title = getTitle());
  });
}

// src/components/Base/index.tsx
var import_jsx_runtime40 = require("react/jsx-runtime");
var defaultTopMenuItems = [
  { link: "https://www.epfl.ch/about/", anchor: "About" },
  { link: "https://www.epfl.ch/education", anchor: "Education" },
  { link: "https://www.epfl.ch/research", anchor: "Research" },
  { link: "https://www.epfl.ch/innovation/", anchor: "Innovation" },
  { link: "https://www.epfl.ch/schools/", anchor: "Schools", active: true },
  { link: "https://www.epfl.ch/campus/", anchor: "Campus" }
];
var defaultBreadcrumbItems = [
  { link: "https://www.epfl.ch/schools/", anchor: "Schools" },
  { link: "https://sti.epfl.ch/", anchor: "School of Engineering" },
  { link: "", anchor: "Elements React", active: true }
];
var defaultDrawerContents = {
  link: "https://www.epfl.ch",
  anchor: "Go to main site"
};
var defaultHomeAnchor = "Home";
var defaultHomeLink = "/";
var defaultIsHome = true;
var defaultShowFooter = true;
var defaultUseLightFooter = false;
function Base({
  children,
  user,
  feedBackEmail,
  homeAnchor = defaultHomeAnchor,
  homeLink = defaultHomeLink,
  isHome = defaultIsHome,
  isLoading = false,
  isBeta = false,
  asideMenuItems,
  // mainMenuItems,
  topMenuItems = defaultTopMenuItems,
  breadcrumbItems = defaultBreadcrumbItems,
  drawerContents = defaultDrawerContents,
  showFooter = defaultShowFooter,
  useLightFooter = defaultUseLightFooter,
  mainContainerClass,
  baseTitle,
  title,
  avatarLogoUrl,
  avatarLogoAltText,
  useReactRouterLinks
}) {
  baseTitle && title && SetPageTitle(baseTitle, title);
  const getBetaAlert = () => /* @__PURE__ */ (0, import_jsx_runtime40.jsx)(
    Alert,
    {
      title: "Beta page:",
      alertType: "info",
      message: "This is not released yet to the standard users. You are seeing it because you belong to the beta testing group."
    }
  );
  return /* @__PURE__ */ (0, import_jsx_runtime40.jsxs)(import_jsx_runtime40.Fragment, { children: [
    /* @__PURE__ */ (0, import_jsx_runtime40.jsxs)("div", { children: [
      isBeta && getBetaAlert(),
      /* @__PURE__ */ (0, import_jsx_runtime40.jsx)(
        Header,
        {
          topMenuItems,
          drawerContents,
          user,
          avatarLogoUrl,
          avatarLogoAltText
        }
      ),
      /* @__PURE__ */ (0, import_jsx_runtime40.jsxs)("div", { className: "main-container", children: [
        /* @__PURE__ */ (0, import_jsx_runtime40.jsx)(Breadcrumbs, { items: breadcrumbItems }),
        /* @__PURE__ */ (0, import_jsx_runtime40.jsxs)("div", { className: "nav-toggle-layout nav-aside-layout", children: [
          /* @__PURE__ */ (0, import_jsx_runtime40.jsx)(Content, { mainContainerClass, children }),
          asideMenuItems && /* @__PURE__ */ (0, import_jsx_runtime40.jsx)(
            Asidemenu,
            {
              isHome,
              feedBackEmail,
              isLoading,
              menuItems: asideMenuItems,
              homeLink,
              homeAnchor,
              useReactRouterLinks
            }
          )
        ] })
      ] })
    ] }),
    showFooter && useLightFooter && /* @__PURE__ */ (0, import_jsx_runtime40.jsx)(FooterLight, {}),
    showFooter && !useLightFooter && /* @__PURE__ */ (0, import_jsx_runtime40.jsx)(Footer, {})
  ] });
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  Alert,
  Asidemenu,
  Avatar,
  Base,
  Breadcrumbs,
  Button,
  Card,
  Carousel,
  Checkbox,
  CheckboxGroup,
  Collapse,
  Content,
  CsfrToken,
  Drawer,
  Dropdown,
  Error,
  ExternalLink,
  Figures,
  FilterBox,
  Footer,
  FooterLight,
  Fullwidthteaser,
  Header,
  Hero,
  Input,
  Language,
  Loader,
  Logo,
  MainMenu,
  Metabox,
  Range,
  Switch,
  Table,
  Tabset,
  Tag,
  Tagset,
  Topmenu,
  Video,
  tabUpdateContents
});
